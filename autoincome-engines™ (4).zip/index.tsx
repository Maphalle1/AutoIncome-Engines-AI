
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  Activity, 
  ArrowLeft,
  ChevronRight, 
  Cpu, 
  Database, 
  Mail, 
  Menu, 
  Plus, 
  Settings, 
  ShieldCheck, 
  Sparkles, 
  TrendingUp, 
  X,
  Zap,
  Shield,
  Layers, 
  Layout, 
  BrainCircuit, 
  Radio,
  History,
  TrendingDown,
  ArrowUpRight,
  Calendar,
  CheckCheck,
  Wrench,
  Trash2,
  HeartPulse,
  ChevronLeft,
  DollarSign,
  LogOut,
  Loader2,
  Send,
  Waves,
  ZapOff,
  Crosshair,
  RefreshCw,
  Image as LucideImage,
  ArrowDownRight,
  Wallet,
  Clock,
  ExternalLink,
  Mic,
  MicOff,
  Speaker,
  Edit3,
  Save
} from 'lucide-react';
import { Modality, LiveServerMessage, Blob } from "@google/genai";
import { apiService } from './services/apiService';

// --- Types & Interfaces ---

type Plan = 'Free Trial' | 'Starter' | 'Pro' | 'Unlimited';
type EngineStatus = 'Active' | 'Paused' | 'Optimizing' | 'Draft';
type TransactionStatus = 'Completed' | 'Processing' | 'Auditing';

interface UserData {
  id: string;
  name: string;
  email: string;
  plan: Plan;
  role: 'User' | 'Admin'; 
  balance: number;
  lifetimeYield: number;
  totalWithdrawn: number;
}

interface Transaction {
  id: string;
  engineId?: string; 
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  status: TransactionStatus;
}

interface Engine {
  id: string;
  name: string;
  type: string;
  model: string;
  status: EngineStatus;
  revenue: number;
  lastSync: string;
  performance: number;
  config: any;
  imageUrl?: string;
  history?: number[]; 
}

interface GridIntelligence {
  macroBriefing: string;
  tacticalDirectives: string[];
  riskLevel: 'Low' | 'Moderate' | 'High' | 'Critical';
}

// --- Constants ---

const DEFAULT_ENGINE_IMAGE = "https://images.unsplash.com/photo-1639322537228-f710d84۶310a?q=80&w=1200&auto=format&fit=crop";

const ENGINE_TEMPLATES = [
  { id: 'affiliate', name: 'Affiliate Magnet', description: 'Automated traffic routing to high-ticket offers using social signal nodes.', icon: TrendingUp, color: 'text-blue-500', yield: 'High Velocity' },
  { id: 'newsletter', name: 'Newsletter Engine', description: 'AI-curated content delivery with dynamic ad placement slots.', icon: Mail, color: 'text-purple-500', yield: 'Steady Growth' },
  { id: 'digital-product', name: 'Digital Delivery', description: 'Complete sales funnel with automated license and asset delivery.', icon: Database, color: 'text-emerald-500', yield: 'Passive Max' },
  { id: 'saas-reseller', name: 'SaaS Resell Node', description: 'Automated white-label provisioning and seat management.', icon: Layers, color: 'text-orange-500', yield: 'Subscription Yield' },
  { id: 'content-bot', name: 'Content Arbitrage', description: 'AI content generation node targeting low-competition search niches.', icon: Sparkles, color: 'text-pink-500', yield: 'Search Arbitrage' },
];

// --- Helper Functions ---

const formatCurrency = (val: any) => {
  const num = typeof val === 'number' && !isNaN(val) ? val : 0;
  return num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

const isEngineIdle = (engine: Engine) => {
  if (engine.status !== 'Active') return true;
  const lastSyncTime = new Date(engine.lastSync).getTime();
  const oneHourAgo = Date.now() - (60 * 60 * 1000);
  return lastSyncTime < oneHourAgo;
};

const generateMockHistory = (base: number, length: number = 24) => {
  return Array.from({ length }).map(() => base + (Math.random() * 10 - 5));
};

// --- Atomic State Components ---

const MetabolismTicker = ({ value, label = "Metabolism", isMain = false }: { value: number, label?: string, isMain?: boolean }) => {
  const [displayValue, setDisplayValue] = useState(value);
  const [delta, setDelta] = useState(0);
  const [showDelta, setShowDelta] = useState(false);
  const prevValue = useRef(value);

  useEffect(() => {
    if (value > prevValue.current) {
      const diff = value - prevValue.current;
      setDelta(diff);
      setShowDelta(true);
      const deltaTimer = setTimeout(() => setShowDelta(false), 2000);
      const start = displayValue;
      const end = value;
      const duration = 800;
      let startTime: number | null = null;
      const animate = (currentTime: number) => {
        if (!startTime) startTime = currentTime;
        const progress = Math.min((currentTime - startTime) / duration, 1);
        setDisplayValue(start + (end - start) * progress);
        if (progress < 1) requestAnimationFrame(animate);
      };
      requestAnimationFrame(animate);
      prevValue.current = value;
      return () => clearTimeout(deltaTimer);
    }
    prevValue.current = value;
  }, [value]);

  return (
    <div className="space-y-0.5 relative group">
      <p className={`font-black uppercase text-white/40 italic ${isMain ? 'text-[10px]' : 'text-[9px]'}`}>{label}</p>
      <div className="flex items-baseline gap-2 overflow-visible">
        <span className={`font-black italic leading-none transition-colors duration-500 ${isMain ? 'text-4xl md:text-5xl text-white' : 'text-3xl text-green-400 drop-shadow-lg'}`}>
          ${formatCurrency(displayValue)}
        </span>
        {showDelta && (
          <span className="absolute -top-2 right-0 font-mono text-[10px] font-black text-emerald-400 animate-in slide-in-from-bottom-2 fade-out duration-1000 fill-mode-forwards pointer-events-none">
            +{(delta).toFixed(4)}
          </span>
        )}
      </div>
    </div>
  );
};

const PerformanceGauge = ({ value }: { value: number }) => {
  const prevValue = useRef(value);
  const [isJittering, setIsJittering] = useState(false);
  useEffect(() => {
    if (Math.abs(value - prevValue.current) > 0.01) {
      setIsJittering(true);
      setTimeout(() => setIsJittering(false), 1000);
      prevValue.current = value;
    }
  }, [value]);
  return (
    <div className="text-right flex flex-col justify-end">
      <p className="text-[9px] font-black uppercase text-white/40 italic">Efficiency</p>
      <div className="flex items-center justify-end gap-2">
        <span className={`text-lg font-black italic transition-all duration-300 ${isJittering ? 'text-blue-400 scale-110' : 'text-blue-500'} leading-none drop-shadow-lg`}>
          {value.toFixed(1)}%
        </span>
        <div className={`w-1.5 h-1.5 rounded-full ${value > 90 ? 'bg-green-500 shadow-[0_0_8px_#10b981]' : 'bg-yellow-500 shadow-[0_0_8px_#f59e0b]'} ${isJittering ? 'animate-ping' : ''}`}></div>
      </div>
    </div>
  );
};

const RecalibrationOverlay = ({ label = "Recalibrating Core..." }: { label?: string }) => {
  const [dots, setDots] = useState("");
  useEffect(() => {
    const i = setInterval(() => setDots(d => (d.length > 2 ? "" : d + ".")), 400);
    return () => clearInterval(i);
  }, []);

  return (
    <div className="absolute inset-0 z-[100] bg-black/80 backdrop-blur-[6px] flex flex-col items-center justify-center space-y-6 animate-in fade-in duration-500">
      <div className="relative w-24 h-24 flex items-center justify-center">
        <div className="absolute inset-0 border-2 border-blue-600/20 rounded-full animate-[spin_10s_linear_infinite]"></div>
        <div className="absolute inset-2 border border-blue-500/30 rounded-full animate-[spin_5s_linear_infinite_reverse]"></div>
        <div className="absolute w-full h-0.5 bg-blue-500/40 animate-neural-scan top-0 left-0"></div>
        <BrainCircuit size={40} className="text-blue-500 animate-pulse drop-shadow-[0_0_12px_rgba(59,130,246,0.6)]" />
      </div>
      <div className="text-center space-y-2">
        <span className="block text-[10px] font-black uppercase tracking-[0.4em] text-blue-500 italic">
          {label.toUpperCase()}{dots}
        </span>
      </div>
    </div>
  );
};

const Card = ({ children, className = '', hover = false, onClick, blueprint = false, image, isPending }: any) => (
  <div onClick={onClick} className={`glass rounded-2xl p-6 transition-all duration-300 relative overflow-hidden group ${hover ? 'hover:border-blue-500/40 hover:scale-[1.01] hover:shadow-glow-sm' : ''} ${className} ${onClick ? 'cursor-pointer' : ''}`}>
    {blueprint && <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:20px_20px]"></div>}
    {image && (
      <>
        <div className="absolute inset-0 z-0 opacity-20 group-hover:opacity-40 pointer-events-none overflow-hidden transition-opacity">
          <img src={image} className="w-full h-full object-cover animate-ken-burns" alt="" />
        </div>
        <div className="absolute inset-0 z-0 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none"></div>
      </>
    )}
    <div className="relative z-10 h-full">{children}</div>
    {isPending && <RecalibrationOverlay label="Recalibrating Core" />}
  </div>
);

const Badge = ({ children, variant = 'info', live = false }: any) => {
  const variants: any = {
    success: "bg-green-500/10 text-green-400 border border-green-500/20",
    warning: "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20",
    info: "bg-blue-500/10 text-blue-400 border border-blue-500/20",
    neutral: "bg-white/5 text-white/50 border border-white/10",
  };
  return (
    <div className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-[10px] uppercase tracking-widest font-black italic ${variants[variant]}`}>
      {live && <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span>}
      {children}
    </div>
  );
};

const Button = ({ children, onClick, variant = 'primary', className = '', icon: Icon, disabled = false, size = 'md', loading = false }: any) => {
  const base = "flex items-center justify-center gap-2 rounded-lg font-bold transition-all duration-300 active:scale-95 disabled:opacity-50 relative overflow-hidden group whitespace-nowrap";
  const variants: any = {
    primary: "bg-[#0070f3] hover:bg-blue-500 text-white shadow-glow",
    secondary: "bg-white/10 hover:bg-white/20 text-white",
    outline: "border border-white/20 hover:border-white/40 text-white",
    danger: "bg-red-500/10 text-red-500 border border-red-500/20",
    success: "bg-green-600 hover:bg-green-500 text-white",
    ghost: "bg-transparent hover:bg-white/5 text-white/60 hover:text-white"
  };
  const sizeClass = size === 'sm' ? "px-4 py-2 text-sm" : "px-6 py-3";
  return (
    <button onClick={onClick} disabled={disabled || loading} className={`${base} ${sizeClass} ${variants[variant]} ${className}`}>
      {loading ? <Activity size={18} className="animate-spin" /> : Icon && <Icon size={18} />}
      {children}
    </button>
  );
};

const Logo = ({ size = 40, className = "", animate = false }: any) => (
  <div className={`flex items-center gap-3 ${className}`}>
    <div className="relative group">
      <div className={`absolute inset-0 bg-blue-600 blur-lg opacity-40 ${animate ? 'animate-pulse' : ''}`}></div>
      <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
        <path d="M50 5L10 25V75L50 95L90 75V25L50 5Z" fill="#0070f3" fillOpacity="0.1" stroke="#0070f3" strokeWidth="4"/>
        <circle cx="50" cy="50" r="22" stroke="#0070f3" strokeWidth="1" strokeDasharray="4 4" className="animate-[spin_15s_linear_infinite]"/>
        <path d="M35 50H65M50 35V65" stroke="white" strokeWidth="4" strokeLinecap="round"/>
      </svg>
    </div>
    <div className="flex flex-col leading-none">
      <span className="text-white text-xl font-black italic tracking-tighter uppercase">AutoIncome</span>
      <span className="text-blue-500 text-[10px] font-black uppercase tracking-[0.3em]">Engines™</span>
    </div>
  </div>
);

// --- Major Views ---

const TreasuryHub = ({ user, transactions, onWithdraw }: any) => {
  return (
    <div className="space-y-12 animate-in fade-in duration-500 px-4 pb-24">
      <div className="flex items-center gap-4">
        <h1 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter text-white">Treasury Registry</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <Card blueprint className="p-8 border-l-4 border-emerald-500">
           <MetabolismTicker value={user.balance} isMain label="Liquid Balance" />
           <Button variant="success" className="mt-6 w-full" icon={ArrowUpRight} onClick={() => onWithdraw(100)}>Authorise Liquidity Exit</Button>
        </Card>
        <Card blueprint className="p-8 border-l-4 border-blue-500">
           <MetabolismTicker value={user.lifetimeYield} label="Lifetime Aggregated Yield" />
        </Card>
        <Card blueprint className="p-8 border-l-4 border-white/10">
           <MetabolismTicker value={user.totalWithdrawn} label="Total Capital Settled" />
        </Card>
      </div>

      <Card blueprint className="p-8 glass">
        <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-6">
           <div className="flex items-center gap-3">
              <History size={20} className="text-blue-500" />
              <h3 className="text-xl font-black italic uppercase text-white">Grid Transaction Logs</h3>
           </div>
        </div>
        <div className="space-y-2 overflow-x-auto">
           <table className="w-full text-left">
              <thead>
                 <tr className="text-[10px] font-black uppercase text-white/20 tracking-widest border-b border-white/5">
                    <th className="pb-4">Timestamp</th>
                    <th className="pb-4">Node Origin</th>
                    <th className="pb-4">Operation</th>
                    <th className="pb-4 text-right">Volume</th>
                    <th className="pb-4 text-right">Status</th>
                 </tr>
              </thead>
              <tbody className="text-xs">
                 {transactions.length > 0 ? transactions.map((tx: any) => (
                    <tr key={tx.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors group">
                       <td className="py-4 font-mono text-white/40">{new Date(tx.date).toLocaleDateString()}</td>
                       <td className="py-4 italic font-black text-white/60">{tx.engineId ? `NODE_${tx.engineId.slice(-4).toUpperCase()}` : 'SYSTEM'}</td>
                       <td className="py-4 font-medium text-white/80">{tx.description}</td>
                       <td className={`py-4 text-right font-black italic ${tx.type === 'credit' ? 'text-emerald-400' : 'text-red-400'}`}>
                          {tx.type === 'credit' ? '+' : '-'}${formatCurrency(tx.amount)}
                       </td>
                       <td className="py-4 text-right">
                          <Badge variant={tx.status === 'Completed' ? 'success' : 'info'}>{tx.status}</Badge>
                       </td>
                    </tr>
                 )) : (
                   <tr>
                     <td colSpan={5} className="py-12 text-center text-white/20 italic uppercase tracking-[0.2em]">Zero Ledger Entries Detected</td>
                   </tr>
                 )}
              </tbody>
           </table>
        </div>
      </Card>
    </div>
  );
};

const EngineBuilder = ({ onDeploy, onCancel }: any) => {
  const [step, setStep] = useState(1);
  const [template, setTemplate] = useState<any>(null);
  const [name, setName] = useState("");
  const [brief, setBrief] = useState("");
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [isVisualizing, setIsVisualizing] = useState(false);
  const [strategy, setStrategy] = useState<any>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  const handleSynthesize = async () => {
    if (!name || !brief) return;
    setIsSynthesizing(true);
    try {
      const response = await apiService.generateStrategy('gemini-3-flash-preview', name, brief, template.name);
      const data = JSON.parse(response.text || "{}");
      setStrategy(data);
      setStep(3);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSynthesizing(false);
    }
  };

  const handleVisualize = async () => {
    if (!strategy) return;
    setIsVisualizing(true);
    try {
      const response = await apiService.generateIcon(`Futuristic cyberpunk tech icon for ${strategy.strategyName}: ${strategy.visualPrompt}. Cinematic lighting, 8k, unreal engine 5 style.`);
      let b64 = "";
      for (const part of (response as any).candidates[0].content.parts) {
        if (part.inlineData) b64 = part.inlineData.data;
      }
      if (b64) setImageUrl(`data:image/png;base64,${b64}`);
    } catch (e) {
      console.error(e);
    } finally {
      setIsVisualizing(false);
    }
  };

  const handleFinalDeploy = () => {
    const newEngine: Engine = {
      id: `engine_${Date.now()}`,
      name,
      type: template.name,
      model: 'Gemini 3 Flash',
      status: 'Active',
      revenue: 0,
      lastSync: new Date().toISOString(),
      performance: 92 + Math.random() * 6,
      config: strategy,
      imageUrl: imageUrl || DEFAULT_ENGINE_IMAGE,
      history: generateMockHistory(95)
    };
    onDeploy(newEngine);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-12 animate-in slide-in-from-bottom-4 duration-500 px-4 pb-24">
      <div className="flex items-center gap-4">
        <button onClick={onCancel} className="p-2 hover:bg-white/5 rounded-full text-white/40 transition-colors"><ArrowLeft size={24}/></button>
        <h1 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter text-white">Node Architect</h1>
      </div>

      <div className="flex gap-4">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className={`h-1.5 flex-1 rounded-full transition-all duration-700 ${step >= i ? 'bg-blue-600 shadow-[0_0_10px_rgba(0,112,243,0.5)]' : 'bg-white/5'}`}></div>
        ))}
      </div>

      {step === 1 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in duration-500">
          {ENGINE_TEMPLATES.map(t => (
            <Card 
              key={t.id} 
              blueprint 
              hover 
              onClick={() => { setTemplate(t); setStep(2); }} 
              className={`p-8 border border-white/5 transition-all ${template?.id === t.id ? 'border-blue-500/40 bg-blue-500/5' : ''}`}
            >
              <t.icon size={32} className={t.color} />
              <h4 className="text-xl font-black italic uppercase text-white mt-4">{t.name}</h4>
              <p className="text-xs italic text-white/40 mt-2 leading-relaxed">{t.description}</p>
              <div className="mt-6">
                <Badge variant="info">{t.yield}</Badge>
              </div>
            </Card>
          ))}
        </div>
      )}

      {step === 2 && (
        <div className="space-y-8 animate-in fade-in duration-500">
           <div className="space-y-3">
              <label className="text-[10px] font-black uppercase text-white/40 italic tracking-widest pl-2">Node Designator</label>
              <input 
                value={name} 
                onChange={e => setName(e.target.value)}
                placeholder="e.g. PROJECT_OMEGA"
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-xl text-white outline-none focus:border-blue-600 transition-all font-black italic shadow-inner" 
              />
           </div>
           <div className="space-y-3">
              <label className="text-[10px] font-black uppercase text-white/40 italic tracking-widest pl-2">Operational Parameters (Briefing)</label>
              <textarea 
                value={brief} 
                onChange={e => setBrief(e.target.value)}
                rows={4}
                placeholder="Define the revenue mechanics, target market, and automation logic..."
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-white outline-none focus:border-blue-600 transition-all italic shadow-inner resize-none" 
              />
           </div>
           <div className="flex gap-4">
             <Button variant="ghost" onClick={() => setStep(1)} className="flex-1">Back</Button>
             <Button onClick={handleSynthesize} loading={isSynthesizing} disabled={!name || !brief} icon={BrainCircuit} className="flex-[2] py-6 shadow-glow">Synthesize Topology</Button>
           </div>
        </div>
      )}

      {step === 3 && strategy && (
        <div className="space-y-8 animate-in fade-in duration-500">
          <Card blueprint className="p-10 space-y-6 glass border-blue-500/20 shadow-glow-sm">
             <div className="flex justify-between items-start">
               <div className="space-y-1">
                 <h3 className="text-2xl font-black italic uppercase text-blue-500">{strategy.strategyName}</h3>
                 <p className="text-[9px] font-black uppercase text-white/30 italic tracking-[0.3em]">Neural Verification Status: Established</p>
               </div>
               <Badge variant="success">Logic Secured</Badge>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-10 py-6">
                <div className="space-y-2 group">
                   <p className="text-[10px] font-black uppercase text-white/20 italic group-hover:text-blue-500 transition-colors">Attack Vector</p>
                   <p className="text-sm italic text-white/80 leading-relaxed font-medium">{strategy.attackVector}</p>
                </div>
                <div className="space-y-2 group">
                   <p className="text-[10px] font-black uppercase text-white/20 italic group-hover:text-emerald-500 transition-colors">Proprietary Moat</p>
                   <p className="text-sm italic text-white/80 leading-relaxed font-medium">{strategy.moat}</p>
                </div>
                <div className="space-y-2 group">
                   <p className="text-[10px] font-black uppercase text-white/20 italic group-hover:text-purple-500 transition-colors">Operational Lever</p>
                   <p className="text-sm italic text-white/80 leading-relaxed font-medium">{strategy.lever}</p>
                </div>
                <div className="space-y-2 group">
                   <p className="text-[10px] font-black uppercase text-white/20 italic group-hover:text-orange-500 transition-colors">Projected ROI</p>
                   <p className="text-sm italic text-white/80 leading-relaxed font-black">{strategy.projectedRevenue}</p>
                </div>
             </div>
          </Card>
          <div className="flex gap-4">
            <Button variant="ghost" onClick={() => setStep(2)} className="flex-1">Back</Button>
            <Button onClick={() => { setStep(4); handleVisualize(); }} icon={LucideImage} className="flex-[2] py-6 shadow-glow">Finalize Identity</Button>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="space-y-8 animate-in fade-in duration-700">
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
              <div className="space-y-8">
                 <div className="space-y-3">
                   <h3 className="text-4xl font-black italic uppercase text-white tracking-tighter">Visual Synthesis</h3>
                   <p className="text-sm text-white/40 leading-relaxed italic font-medium">The Grid is generating a unique visual identifier for project <span className="text-white">"{name}"</span>. This core identity will be used for real-time tracking in the Command Center.</p>
                 </div>
                 <Card className="p-5 bg-white/5 border border-white/5 rounded-2xl group hover:border-blue-500/20 transition-all">
                    <p className="text-[10px] font-black uppercase text-white/20 mb-3 italic tracking-widest">Neural Visual Prompt Hash</p>
                    <p className="text-[11px] text-white/40 italic line-clamp-3 leading-relaxed group-hover:text-white/60 transition-colors">{strategy?.visualPrompt}</p>
                 </Card>
                 <div className="pt-4">
                   <Button onClick={handleFinalDeploy} disabled={isVisualizing} size="lg" className="w-full py-6 shadow-glow text-xl italic" icon={CheckCheck}>Deploy to Grid Matrix</Button>
                 </div>
              </div>
              <div className="aspect-[16/9] lg:aspect-square glass rounded-3xl overflow-hidden relative flex items-center justify-center border border-white/10 shadow-3xl">
                 {isVisualizing ? (
                   <div className="flex flex-col items-center gap-6">
                      <div className="relative">
                        <Loader2 size={48} className="text-blue-500 animate-spin" />
                        <div className="absolute inset-0 bg-blue-500 blur-2xl opacity-20 animate-pulse"></div>
                      </div>
                      <p className="text-[10px] font-black uppercase italic text-blue-500 animate-pulse tracking-[0.4em]">Rendering Logic Core...</p>
                   </div>
                 ) : (
                   imageUrl ? (
                    <img src={imageUrl} className="w-full h-full object-cover animate-ken-burns" />
                   ) : (
                    <div className="text-white/10 italic text-xs uppercase tracking-widest">Awaiting Render</div>
                   )
                 )}
                 <div className="absolute inset-0 pointer-events-none border-[12px] border-black/20"></div>
                 <div className="absolute inset-0 pointer-events-none border border-white/5"></div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

const NeuralBridge = ({ onExit }: any) => {
  const [isLive, setIsLive] = useState(false);
  const [signalStrength, setSignalStrength] = useState(0);
  const [uplinkLog, setUplinkLog] = useState<string[]>([]);

  useEffect(() => {
    if (isLive) {
      const i = setInterval(() => {
        setSignalStrength(88 + Math.random() * 10);
        if (Math.random() > 0.7) {
          const logs = [
            "Syncing neural lattice...",
            "Decrypting sub-space packets...",
            "Stable uplink established via Node-7",
            "Latency verification: 14ms",
            "Optimizing memory buffers...",
            "Packet injection successful."
          ];
          setUplinkLog(prev => [logs[Math.floor(Math.random() * logs.length)], ...prev].slice(0, 5));
        }
      }, 1000);
      return () => clearInterval(i);
    }
  }, [isLive]);

  return (
    <div className="max-w-4xl mx-auto space-y-12 animate-in fade-in duration-500 px-4 pb-24">
       <div className="flex justify-between items-center">
         <div className="space-y-1">
           <h1 className="text-4xl md:text-5xl font-black italic uppercase tracking-tighter text-white">Neural Bridge</h1>
           <p className="text-blue-500 text-[10px] font-black uppercase tracking-[0.3em] italic">Direct Architect-to-Grid Interface</p>
         </div>
         <Button variant="ghost" onClick={onExit} icon={X} className="hover:bg-red-500/10 hover:text-red-500 transition-all">Terminate Link</Button>
       </div>

       <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <Card blueprint className="p-12 flex flex-col items-center justify-center space-y-10 glass border-blue-500/20 aspect-square shadow-glow">
             <div className="relative">
                <div className={`w-56 h-56 rounded-full border-4 flex items-center justify-center transition-all duration-1000 ${isLive ? 'border-blue-500 shadow-glow scale-110' : 'border-white/5 opacity-20'}`}>
                   <Radio size={80} className={isLive ? 'text-blue-500 animate-pulse' : 'text-white/20'} />
                </div>
                {isLive && (
                  <>
                    <div className="absolute inset-0 animate-ping opacity-10">
                      <div className="w-full h-full rounded-full border-2 border-blue-500"></div>
                    </div>
                    <div className="absolute -top-4 -right-4">
                      <Badge variant="success" live>Live</Badge>
                    </div>
                  </>
                )}
             </div>
             
             <div className="text-center space-y-3">
                <p className="text-3xl font-black italic uppercase text-white tracking-tighter">{isLive ? 'Uplink Established' : 'System Standby'}</p>
                {isLive && (
                  <div className="flex flex-col items-center gap-1">
                    <p className="text-[10px] font-black uppercase italic text-blue-500 tracking-widest">Core Flux: {signalStrength.toFixed(2)}%</p>
                    <div className="w-32 h-1 bg-white/5 rounded-full overflow-hidden mt-2">
                       <div className="h-full bg-blue-500 transition-all duration-300" style={{ width: `${signalStrength}%` }}></div>
                    </div>
                  </div>
                )}
             </div>

             {!isLive ? (
               <Button onClick={() => setIsLive(true)} size="lg" icon={Zap} className="px-16 py-5 text-lg italic shadow-glow">Initiate Uplink</Button>
             ) : (
               <Button onClick={() => setIsLive(false)} variant="danger" icon={ZapOff} className="px-12 py-4 italic">Sever Bridge</Button>
             )}
          </Card>

          <div className="flex flex-col gap-8">
             <Card blueprint className="p-8 glass flex-1 flex flex-col min-h-[300px] border border-white/5 group">
                <div className="flex items-center gap-3 mb-8">
                   <Waves size={24} className="text-blue-500 group-hover:animate-pulse transition-all" />
                   <h3 className="text-xl font-black italic uppercase text-white">Sub-Neural Spectrum</h3>
                </div>
                <div className="flex-1 flex items-end gap-1.5 min-h-[150px] relative">
                   {Array.from({ length: 24 }).map((_, i) => (
                      <div 
                        key={i} 
                        className="flex-1 bg-blue-600/40 rounded-t transition-all duration-500 hover:bg-blue-400"
                        style={{ height: isLive ? `${15 + Math.random() * 85}%` : '4px' }}
                      ></div>
                   ))}
                   {!isLive && <div className="absolute inset-0 flex items-center justify-center italic text-[10px] text-white/10 uppercase tracking-[0.4em]">Spectrum Offline</div>}
                </div>
                <div className="mt-10 grid grid-cols-2 gap-4">
                   <div className="p-3 bg-white/5 rounded-xl border border-white/5">
                      <p className="text-[9px] font-black uppercase text-white/20 italic mb-1">Frequency</p>
                      <p className="text-sm font-black italic text-white/80">{isLive ? '44.1 kHz' : '0.0 kHz'}</p>
                   </div>
                   <div className="p-3 bg-white/5 rounded-xl border border-white/5">
                      <p className="text-[9px] font-black uppercase text-white/20 italic mb-1">Latency</p>
                      <p className="text-sm font-black italic text-white/80">{isLive ? '14 ms' : '-- ms'}</p>
                   </div>
                </div>
             </Card>

             <Card className="p-6 bg-black/40 border border-white/5 rounded-2xl flex-1 max-h-[160px] overflow-hidden">
                <p className="text-[10px] font-black uppercase text-white/30 italic mb-3 border-b border-white/5 pb-2">Link Telemetry Log</p>
                <div className="space-y-2">
                  {isLive ? uplinkLog.map((log, i) => (
                    <p key={i} className="text-[10px] font-mono text-emerald-500/60 flex items-center gap-2 animate-in slide-in-from-left-2">
                      <span className="text-[8px] text-white/10">{new Date().toLocaleTimeString()}</span>
                      <span className="opacity-80">>></span> {log}
                    </p>
                  )) : (
                    <p className="text-[10px] italic text-white/10 font-mono">No telemetry detected...</p>
                  )}
                </div>
             </Card>
          </div>
       </div>
    </div>
  );
};

// --- View Nodes ---

/**
 * GridIntelligenceNode provides macro-strategic oversight using the Gemini API.
 */
const GridIntelligenceNode = ({ engines, treasury }: { engines: Engine[], treasury: number }) => {
  const [intel, setIntel] = useState<GridIntelligence | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchIntel = async () => {
      setLoading(true);
      try {
        const response = await apiService.getGridIntelligence(engines, treasury, []);
        const data = JSON.parse(response.text || "{}");
        setIntel(data);
      } catch (e) {
        console.error("Failed to fetch grid intel:", e);
      } finally {
        setLoading(false);
      }
    };
    fetchIntel();
  }, [engines.length, treasury]);

  return (
    <Card blueprint className="p-8 border border-white/5 bg-blue-500/5 relative overflow-hidden group">
      <div className="absolute top-0 right-0 p-4">
        {intel && (
          <Badge variant={intel.riskLevel === 'Low' ? 'success' : intel.riskLevel === 'High' ? 'warning' : 'info'}>
            Risk: {intel.riskLevel}
          </Badge>
        )}
      </div>
      <div className="flex items-center gap-4 mb-6">
        <div className="p-3 bg-blue-600/20 rounded-xl">
          <BrainCircuit size={24} className="text-blue-500" />
        </div>
        <div>
          <h3 className="text-xl font-black italic uppercase text-white tracking-tighter">Grid Intelligence Core</h3>
          <p className="text-[10px] font-black uppercase text-white/30 italic tracking-[0.2em]">Strategic Neural Analysis</p>
        </div>
      </div>
      {loading ? (
        <div className="flex items-center gap-3 py-4">
          <Loader2 size={16} className="animate-spin text-blue-500" />
          <span className="text-xs italic text-white/40 uppercase tracking-widest">Running Global Simulation...</span>
        </div>
      ) : (
        <div className="space-y-6">
          <p className="text-sm italic text-white/80 leading-relaxed font-medium border-l-2 border-blue-500/30 pl-4">
            {intel?.macroBriefing || "Initializing macro data streams..."}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {intel?.tacticalDirectives.map((directive, i) => (
              <div key={i} className="p-4 bg-white/5 rounded-xl border border-white/5 group hover:border-blue-500/20 transition-all">
                <p className="text-[9px] font-black uppercase text-blue-500/60 mb-1 italic">Directive {i + 1}</p>
                <p className="text-[11px] text-white/60 italic leading-tight group-hover:text-white transition-colors">{directive}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </Card>
  );
};

/**
 * EngineDetailView allows for fine-tuned node management and "Neural Spirit" interaction.
 */
const EngineDetailView = ({ engine, transactions, isPending, onBack, onDeleteRequest, onUpdateEngine }: any) => {
  const [chatMessage, setChatMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<any[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [isImgLoading, setIsImgLoading] = useState(true);
  
  // New State for Editable Config
  const [isEditingConfig, setIsEditingConfig] = useState(false);
  const [tempConfig, setTempConfig] = useState<any>(engine.config || {});

  const chatRef = useRef<any>(null);

  useEffect(() => {
    chatRef.current = apiService.createEngineChat(engine);
  }, [engine.id]);

  useEffect(() => {
    setTempConfig(engine.config || {});
  }, [engine.config]);

  const handleSendMessage = async () => {
    const sanitizedMsg = chatMessage.trim();
    if (!sanitizedMsg || isSending) return;

    setChatMessage("");
    setIsSending(true);
    setChatHistory(prev => [...prev, { role: 'user', text: sanitizedMsg }]);

    try {
      const result = await chatRef.current.sendMessage({ message: sanitizedMsg });
      const modelText = result.text || "Neural uplink stable but zero payload received.";
      setChatHistory(prev => [...prev, { role: 'model', text: modelText }]);
    } catch (e) {
      console.error("Neural Bridge transmission error:", e);
      setChatHistory(prev => [...prev, { role: 'model', text: "CRITICAL ERROR: Neural uplink desynchronized. Directive failed to propagate." }]);
    } finally {
      setIsSending(false);
    }
  };

  const handleSaveConfig = () => {
    onUpdateEngine(engine.id, { config: tempConfig });
    setIsEditingConfig(false);
  };

  const handleConfigChange = (key: string, value: string) => {
    setTempConfig(prev => ({ ...prev, [key]: value }));
  };

  const idle = isEngineIdle(engine);

  return (
    <div className="space-y-12 animate-in slide-in-from-right-4 duration-500 pb-24">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-6">
          <button onClick={onBack} className="p-3 hover:bg-white/5 rounded-2xl text-white/40 transition-colors border border-white/5"><ChevronLeft size={24}/></button>
          <div className="space-y-1">
             <h1 className="text-4xl md:text-5xl font-black italic uppercase tracking-tighter text-white">{engine.name}</h1>
             <p className="text-blue-500 text-[10px] font-black uppercase tracking-[0.3em] italic">{engine.type} // Model: {engine.model}</p>
          </div>
        </div>
        <div className="flex gap-4">
           <Button variant="danger" icon={Trash2} onClick={onDeleteRequest} size="sm" disabled={isPending}>Decommission</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-10">
           {/* Efficient Image Loading with Placeholder & Refined Idle State */}
           <Card blueprint className={`p-0 border border-white/5 aspect-video md:aspect-[21/9] rounded-3xl overflow-hidden relative group bg-white/5 ${idle ? 'animate-idle-breath' : ''}`}>
              {isImgLoading && (
                <div className="absolute inset-0 flex items-center justify-center z-20 bg-black/40 backdrop-blur-sm animate-pulse">
                   <div className="flex flex-col items-center gap-3">
                      <Loader2 size={32} className="text-blue-500 animate-spin opacity-50" />
                      <span className="text-[10px] font-black uppercase tracking-[0.4em] text-white/20 italic">Loading Vis-Core</span>
                   </div>
                </div>
              )}
              <img 
                src={engine.imageUrl || DEFAULT_ENGINE_IMAGE} 
                onLoad={() => setIsImgLoading(false)}
                className={`w-full h-full object-cover transition-all duration-[2.5s] group-hover:scale-110 ${isImgLoading ? 'opacity-0 scale-105' : 'opacity-100 scale-100'}`} 
                alt={engine.name}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"></div>
              
              {/* Idle State Overlay (Subtle Scan) */}
              {idle && (
                 <div className="absolute inset-0 z-30 pointer-events-none overflow-hidden bg-black/30 backdrop-blur-[1px]">
                    <div className="absolute w-full h-[2px] bg-white/5 animate-power-save-scan"></div>
                    <div className="absolute inset-0 flex flex-col items-center justify-center opacity-40">
                       <ZapOff size={40} className="text-white mb-2" />
                       <span className="text-[9px] font-black uppercase tracking-[0.5em] text-white italic">Hibernation Registry Active</span>
                    </div>
                 </div>
              )}

              <div className="absolute bottom-8 left-8 right-8 flex items-end justify-between">
                <div className="space-y-1">
                  <p className="text-[10px] font-black uppercase text-white/60 italic tracking-widest">Core Status</p>
                  <Badge variant={engine.status === 'Active' ? 'success' : 'warning'} live={engine.status === 'Active'}>{engine.status}</Badge>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-black uppercase text-white/60 italic tracking-widest">Efficiency Rating</p>
                  <p className="text-3xl font-black italic text-blue-500 drop-shadow-glow">{engine.performance.toFixed(1)}%</p>
                </div>
              </div>
              {isPending && <RecalibrationOverlay />}
           </Card>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card blueprint className="p-8 glass">
                 <div className="flex items-center gap-3 mb-6">
                    <TrendingUp size={20} className="text-emerald-500" />
                    <h3 className="text-lg font-black italic uppercase text-white">Yield Ledger</h3>
                 </div>
                 <MetabolismTicker value={engine.revenue} isMain label="Total Revenue Extracted" />
                 <div className="mt-8 space-y-3">
                    {transactions.slice(0, 4).map((tx: any) => (
                       <div key={tx.id} className="flex justify-between items-center py-2 border-b border-white/5 last:border-0">
                          <span className="text-[10px] text-white/40 italic">{new Date(tx.date).toLocaleDateString()}</span>
                          <span className="text-xs font-black italic text-emerald-400">+${tx.amount.toFixed(2)}</span>
                       </div>
                    ))}
                    {transactions.length === 0 && <p className="text-[10px] text-white/20 italic text-center py-4">Waiting for first yield event...</p>}
                 </div>
              </Card>

              <Card blueprint className="p-8 glass">
                 <div className="flex items-center gap-3 mb-6">
                    <Settings size={20} className="text-blue-500" />
                    <h3 className="text-lg font-black italic uppercase text-white">Logic Toggles</h3>
                 </div>
                 <div className="space-y-4">
                    <Button 
                      variant={engine.status === 'Active' ? 'secondary' : 'success'} 
                      className="w-full justify-start py-4" 
                      icon={engine.status === 'Active' ? ZapOff : Zap}
                      loading={isPending}
                      disabled={isPending}
                      onClick={() => onUpdateEngine(engine.id, { status: engine.status === 'Active' ? 'Paused' : 'Active' })}
                    >
                      {engine.status === 'Active' ? 'Pause Operations' : 'Resume Operations'}
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start py-4" 
                      icon={RefreshCw}
                      loading={isPending}
                      disabled={isPending}
                      onClick={() => onUpdateEngine(engine.id, { performance: 90 + Math.random() * 10 })}
                    >
                      Recalibrate Flux
                    </Button>
                 </div>
              </Card>
           </div>

           <Card blueprint className="p-8 glass">
              <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-4">
                 <div className="flex items-center gap-3">
                    <Database size={20} className="text-purple-500" />
                    <h3 className="text-lg font-black italic uppercase text-white">Configuration Topology</h3>
                 </div>
                 {!isEditingConfig ? (
                   <Button variant="ghost" size="sm" icon={Edit3} onClick={() => setIsEditingConfig(true)}>Edit Logic</Button>
                 ) : (
                   <div className="flex gap-2">
                     <Button variant="ghost" size="sm" icon={X} onClick={() => { setIsEditingConfig(false); setTempConfig(engine.config); }}>Abort</Button>
                     <Button variant="success" size="sm" icon={Save} onClick={handleSaveConfig} disabled={isPending}>Commit</Button>
                   </div>
                 )}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 {Object.entries(tempConfig).filter(([k]) => k !== 'visualPrompt').map(([key, val]: [string, any]) => (
                    <div key={key} className="space-y-1 group">
                       <p className="text-[10px] font-black uppercase text-white/20 italic tracking-widest group-hover:text-blue-500 transition-colors">
                         {key.replace(/([A-Z])/g, ' $1').trim()}
                       </p>
                       {isEditingConfig ? (
                         <textarea 
                           value={val}
                           rows={2}
                           onChange={(e) => handleConfigChange(key, e.target.value)}
                           className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-blue-500 transition-all italic resize-none shadow-inner"
                         />
                       ) : (
                         <p className="text-sm text-white/80 font-medium italic leading-relaxed">{val}</p>
                       )}
                    </div>
                 ))}
              </div>
           </Card>
        </div>

        <Card className="lg:sticky lg:top-12 h-[calc(100vh-12rem)] min-h-[500px] flex flex-col p-0 glass border-blue-500/20 shadow-glow">
           <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/5">
              <div className="flex items-center gap-3">
                 <div className="relative">
                   <BrainCircuit size={20} className="text-blue-500" />
                   <div className="absolute inset-0 bg-blue-500 blur-lg opacity-40 animate-pulse"></div>
                 </div>
                 <h3 className="text-sm font-black italic uppercase text-white">Neural Spirit</h3>
              </div>
              <Badge variant="info" live>Connected</Badge>
           </div>
           
           <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide">
              <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-2xl">
                 <p className="text-[10px] text-blue-400 italic leading-relaxed">System initialized. Neural Spirit of <span className="font-black">"{engine.name}"</span> is online and awaiting directives from the Architect.</p>
              </div>
              {chatHistory.map((msg, i) => (
                 <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-4 rounded-2xl text-xs leading-relaxed italic ${msg.role === 'user' ? 'bg-blue-600 text-white shadow-glow' : 'bg-white/5 text-white/80 border border-white/10'}`}>
                       {msg.text}
                    </div>
                 </div>
              ))}
              {isSending && (
                 <div className="flex justify-start">
                    <div className="bg-white/5 border border-white/10 p-4 rounded-2xl">
                       <Loader2 size={16} className="text-blue-500 animate-spin" />
                    </div>
                 </div>
              )}
           </div>

           <div className="p-6 bg-black/40 border-t border-white/5">
              <div className="relative">
                 <input 
                   value={chatMessage}
                   onChange={e => setChatMessage(e.target.value)}
                   onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                   placeholder="Transmit directive..."
                   className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-5 pr-14 text-xs text-white outline-none focus:border-blue-500 transition-all italic"
                 />
                 <button 
                   onClick={handleSendMessage}
                   disabled={!chatMessage.trim() || isSending}
                   title={!chatMessage.trim() ? "Directive payload empty" : "Transmit payload"}
                   className="absolute right-2 top-2 bottom-2 aspect-square flex items-center justify-center bg-blue-600 rounded-lg text-white hover:bg-blue-500 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                 >
                   <Send size={14} />
                 </button>
              </div>
           </div>
        </Card>
      </div>
    </div>
  );
};

// --- Main App Shell ---

const App = () => {
  const [view, setView] = useState('dashboard');
  const [user, setUser] = useState<UserData | null>(null);
  const [engines, setEngines] = useState<Engine[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [toast, setToast] = useState<any>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isBooting, setIsBooting] = useState(false);
  const [pendingUpdates, setPendingUpdates] = useState<Set<string>>(new Set());

  // --- Core Lifecycle ---

  useEffect(() => {
    const savedEngines = localStorage.getItem('autoincome_engines');
    if (savedEngines) setEngines(JSON.parse(savedEngines));
    const savedUser = localStorage.getItem('autoincome_user');
    if (savedUser) { setUser(JSON.parse(savedUser)); setIsBooting(true); }
    const savedTxs = localStorage.getItem('autoincome_txs');
    if (savedTxs) setTransactions(JSON.parse(savedTxs));
  }, []);

  useEffect(() => {
    if (engines.length > 0) localStorage.setItem('autoincome_engines', JSON.stringify(engines));
    if (transactions.length > 0) localStorage.setItem('autoincome_txs', JSON.stringify(transactions));
  }, [engines, transactions]);

  // Yield Simulation Cycle
  useEffect(() => {
    if (!user) return;
    const interval = setInterval(() => {
      let totalTickRevenue = 0;
      let newTxs: Transaction[] = [];
      setEngines(prev => prev.map(e => {
        if (e.status === 'Active' && !pendingUpdates.has(e.id)) {
          const tick = Math.random() * 0.05;
          totalTickRevenue += tick;
          if (Math.random() > 0.985) {
             newTxs.push({ 
               id: `ntx_${Date.now()}_${e.id}`, 
               engineId: e.id, 
               date: new Date().toISOString(), 
               description: `Yield Event: ${e.name}`, 
               amount: 5 + Math.random() * 15, 
               type: 'credit', 
               status: 'Completed' 
             });
          }
          return { ...e, revenue: (e.revenue ?? 0) + tick, lastSync: new Date().toISOString() };
        }
        return e;
      }));
      if (newTxs.length > 0) setTransactions(prev => [...newTxs, ...prev].slice(0, 100));
      if (totalTickRevenue > 0) {
        setUser(prev => prev ? ({ ...prev, balance: prev.balance + totalTickRevenue, lifetimeYield: prev.lifetimeYield + totalTickRevenue }) : null);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [user?.id, engines.length, pendingUpdates]);

  // --- Handlers ---

  const handleUpdateEngine = async (id: string, updateOrTransform: any, notify: boolean = true) => {
    if (pendingUpdates.has(id)) return;
    setPendingUpdates(prev => new Set(prev).add(id));
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1500)); 
      
      setEngines(prev => {
        const targetIndex = prev.findIndex(e => e.id === id);
        if (targetIndex === -1) return prev;
        const target = prev[targetIndex];
        const update = typeof updateOrTransform === 'function' ? updateOrTransform(target) : updateOrTransform;
        const next = [...prev];
        next[targetIndex] = { ...target, ...update };
        return next;
      });

      if (notify) {
        setToast({ title: "Node Recalibrated", type: "success" });
        setTimeout(() => setToast(null), 3000);
      }
    } catch (error) {
      console.error("Neural update failed:", error);
      setToast({ title: "Recalibration Failed", type: "warning" });
      setTimeout(() => setToast(null), 3000);
    } finally {
      setPendingUpdates(prev => { 
        const next = new Set(prev); 
        next.delete(id); 
        return next; 
      });
    }
  };

  const handleWithdraw = (amount: number) => {
    if (!user || user.balance < amount) {
      setToast({ title: "Insufficient Liquidity", type: "warning" });
      setTimeout(() => setToast(null), 3000);
      return;
    }
    const withdrawalTx: Transaction = {
       id: `wtx_${Date.now()}`,
       date: new Date().toISOString(),
       description: 'Liquidity Exit (Withdrawal)',
       amount,
       type: 'debit',
       status: 'Completed'
    };
    setTransactions(prev => [withdrawalTx, ...prev]);
    setUser({ ...user, balance: user.balance - amount, totalWithdrawn: user.totalWithdrawn + amount });
    setToast({ title: "Liquidity Exit Authorized", type: "success" });
    setTimeout(() => setToast(null), 3000);
  };

  const handleDeployEngine = (e: Engine) => {
    setEngines(prev => [e, ...prev]);
    setView('dashboard');
    setToast({ title: "Deployment Successful", type: "success" });
    setTimeout(() => setToast(null), 3000);
  };

  const renderContent = () => {
    if (!user) return null;

    if (view === 'dashboard') {
      return (
        <div className="space-y-12 animate-in fade-in duration-700 px-4 pb-24">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
            <div className="space-y-1">
              <h1 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter text-white leading-none">Command Center</h1>
              <p className="text-white/40 text-sm italic font-medium">Active Node Matrix Registry</p>
            </div>
            <Button onClick={() => setView('builder')} icon={Plus} size="lg" className="shadow-glow">Initialize New Node</Button>
          </div>
          
          <GridIntelligenceNode engines={engines} treasury={user.balance} />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card blueprint onClick={() => setView('treasury')} hover className="p-10 border-l-4 border-blue-600 glass shadow-glow">
              <MetabolismTicker value={user.balance} isMain label="Total Liquidity" />
              <div className="absolute top-4 right-4 opacity-20 group-hover:opacity-100 transition-opacity">
                 <ChevronRight size={24} className="text-blue-500" />
              </div>
            </Card>
            <Card blueprint className="p-10 glass border border-white/5">
              <div className="text-[10px] font-black uppercase text-white/30 italic tracking-widest">Uplink Quality</div>
              <div className="text-4xl md:text-5xl font-black text-green-400 italic tracking-tighter leading-none uppercase mt-2">Stabilized</div>
              <div className="mt-4 flex items-center gap-2">
                 <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>
                 <span className="text-[9px] font-black uppercase text-white/20 italic tracking-widest">Global Sync Active</span>
              </div>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {engines.length > 0 ? engines.map(e => {
              const idle = isEngineIdle(e);
              const isPending = pendingUpdates.has(e.id);
              return (
                <Card 
                  key={e.id} 
                  hover 
                  image={e.imageUrl || DEFAULT_ENGINE_IMAGE} 
                  onClick={() => !isPending && setView(`engine-${e.id}`)} 
                  isPending={isPending} 
                  className={`min-h-[280px] flex flex-col justify-between glass border border-white/5 shadow-2xl transition-all ${idle ? 'animate-idle-breath grayscale-[0.6] opacity-70' : ''}`} 
                >
                  {/* Subtle Scan Overlay for Idle Engines */}
                  {idle && (
                    <div className="absolute inset-0 z-20 pointer-events-none overflow-hidden rounded-2xl">
                       <div className="absolute w-full h-[1px] bg-white/10 animate-power-save-scan"></div>
                    </div>
                  )}

                  <div className="flex justify-between items-start mb-4">
                    <div className="space-y-1">
                      <h4 className="text-2xl font-black italic uppercase tracking-tighter text-white leading-none group-hover:text-blue-400 transition-colors">{e.name}</h4>
                      <p className="text-[10px] font-black uppercase text-white/40 tracking-[0.2em] italic">{e.type}</p>
                    </div>
                    <Badge variant={e.status === 'Active' ? 'success' : 'warning'} live={e.status === 'Active'}>{e.status}</Badge>
                  </div>
                  <div className="mt-auto grid grid-cols-2 gap-4">
                    <MetabolismTicker value={e.revenue} />
                    <PerformanceGauge value={e.performance} />
                  </div>
                </Card>
              );
            }) : (
              <div className="col-span-full py-24 text-center space-y-6 opacity-30 group cursor-pointer hover:opacity-100 transition-all" onClick={() => setView('builder')}>
                <LucideImage size={64} className="mx-auto text-white/20 group-hover:text-blue-500/50 transition-all animate-pulse" />
                <div className="space-y-2">
                  <p className="italic font-black uppercase text-xs tracking-[0.4em]">Node Matrix Empty</p>
                  <p className="text-[9px] font-black uppercase text-white/40 italic">Initialize your first architect engine</p>
                </div>
              </div>
            )}
          </div>
        </div>
      );
    }

    if (view === 'builder') return <EngineBuilder onDeploy={handleDeployEngine} onCancel={() => setView('dashboard')} />;
    if (view === 'treasury') return <TreasuryHub user={user} transactions={transactions} onWithdraw={handleWithdraw} />;
    if (view === 'hub') return <NeuralBridge onExit={() => setView('dashboard')} />;
    if (view === 'settings') return <div className="p-12 text-center opacity-40 italic">Terminal configuration module... <Button variant="ghost" className="mt-8" onClick={() => setView('dashboard')}>Back to Command</Button></div>;

    if (view.startsWith('engine-')) {
      const id = view.slice(7);
      const e = engines.find(node => node.id === id);
      const txs = transactions.filter(t => t.engineId === id);
      return e ? (
        <EngineDetailView 
          engine={e} 
          transactions={txs} 
          isPending={pendingUpdates.has(id)} 
          onBack={() => setView('dashboard')} 
          onDeleteRequest={() => { setEngines(prev => prev.filter(n => n.id !== id)); setView('dashboard'); }} 
          onUpdateEngine={handleUpdateEngine} 
        />
      ) : null;
    }

    return <div className="p-12 text-center opacity-40 italic uppercase tracking-[0.3em]">Module synchronized...</div>;
  };

  const handleLogin = (email: string) => {
    const newUser: UserData = { 
      id: 'u1', name: 'Lead Architect', email, plan: 'Unlimited', role: 'Admin', balance: 1337.42, lifetimeYield: 1337.42, totalWithdrawn: 0 
    };
    setUser(newUser);
    localStorage.setItem('autoincome_user', JSON.stringify(newUser));
    setIsBooting(true);
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#050505] p-6 relative overflow-hidden">
        <div className="fixed inset-0 pointer-events-none blueprint-bg opacity-[0.2]"></div>
        <Card blueprint className="w-full max-w-md p-12 glass border-blue-500/20 text-center space-y-10 animate-in zoom-in-95 duration-700 shadow-glow">
           <div className="flex flex-col items-center">
             <Logo size={80} animate className="justify-center" />
           </div>
           <div className="space-y-2">
             <h2 className="text-3xl font-black italic uppercase text-white tracking-tighter">Grid Access Request</h2>
             <p className="text-[10px] font-black uppercase text-white/30 italic tracking-widest">Biometric Uplink Required</p>
           </div>
           <div className="space-y-4">
             <input 
              placeholder="Architect ID (Email)" 
              className="w-full bg-white/5 border border-white/10 rounded-xl p-5 text-white outline-none focus:border-blue-600 italic font-medium transition-all text-center" 
             />
             <Button onClick={() => handleLogin("architect@grid.io")} className="w-full py-6 text-xl shadow-glow italic" size="lg">Establish Neural Link</Button>
           </div>
           <div className="pt-4 border-t border-white/5 opacity-20">
             <p className="text-[9px] font-black uppercase text-white tracking-widest italic">Sovereign Revenue OS v2.5.1</p>
           </div>
        </Card>
      </div>
    );
  }

  if (isBooting) {
    return (
      <div className="fixed inset-0 z-[100] bg-[#050505] flex flex-col items-center justify-center p-6">
        <div className="relative mb-12">
          <Logo size={100} animate />
          <div className="absolute inset-0 blur-3xl bg-blue-600 opacity-20 animate-pulse"></div>
        </div>
        <div className="flex flex-col items-center gap-2">
          <p className="text-[10px] font-black uppercase tracking-[0.5em] text-blue-500 animate-pulse italic">Neural Handshake Active...</p>
          <div className="w-48 h-1 bg-white/5 rounded-full overflow-hidden mt-4">
             <div className="h-full bg-blue-500 animate-[shimmer-sweep_2s_linear_infinite]"></div>
          </div>
        </div>
        <Button onClick={() => setIsBooting(false)} variant="ghost" className="mt-16 opacity-10 hover:opacity-100 transition-opacity">Skip Handshake</Button>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen bg-[#050505] md:flex text-white selection:bg-blue-600 selection:text-white overflow-hidden">
      <div className="fixed inset-0 pointer-events-none blueprint-bg opacity-[0.3]"></div>
      <aside className={`fixed top-0 left-0 h-full z-[70] w-72 border-r border-white/5 p-8 flex flex-col bg-black/90 backdrop-blur-3xl transition-transform duration-500 -translate-x-full md:relative md:translate-x-0 ${isMenuOpen ? 'translate-x-0' : ''}`}>
        <Logo size={40} animate />
        <nav className="space-y-2 mt-12 flex-1 overflow-y-auto scrollbar-hide">
          {[
            { id: 'dashboard', label: 'Command Center', icon: Layout },
            { id: 'treasury', label: 'Treasury Hub', icon: DollarSign },
            { id: 'hub', label: 'Neural Bridge', icon: BrainCircuit },
            { id: 'settings', label: 'Terminal Prefs', icon: Settings },
          ].map(item => (
            <button 
              key={item.id} 
              onClick={() => { setView(item.id); setIsMenuOpen(false); }} 
              className={`w-full flex items-center gap-5 px-6 py-4 rounded-2xl font-black uppercase text-[10px] tracking-[0.2em] italic transition-all group relative ${view === item.id ? 'bg-blue-600 text-white shadow-glow' : 'text-white/40 hover:text-white hover:bg-white/5'}`}
            >
              <item.icon size={20} className={view === item.id ? 'text-white' : 'text-white/20 group-hover:text-blue-500'} /> 
              <span>{item.label}</span>
              {view === item.id && <div className="absolute right-4 w-1 h-4 bg-white/40 rounded-full"></div>}
            </button>
          ))}
        </nav>
        <div className="mt-auto pt-8 border-t border-white/5">
           <Button variant="ghost" className="w-full opacity-40 hover:opacity-100 text-xs italic font-black uppercase tracking-widest" icon={LogOut} onClick={() => { setUser(null); localStorage.clear(); }}>Sever Uplink</Button>
        </div>
      </aside>
      <main className="flex-1 w-full p-6 md:p-12 lg:p-16 pb-24 overflow-y-auto relative z-10 scrollbar-hide">
        <header className="mb-12 flex items-center justify-between">
          <button onClick={() => setIsMenuOpen(true)} className="md:hidden p-3 bg-black/50 rounded-2xl text-white backdrop-blur-2xl border border-white/10 shadow-glow-sm"><Menu size={24}/></button>
          {toast && (
            <div className={`absolute top-6 left-1/2 -translate-x-1/2 glass border rounded-2xl p-4 animate-in slide-in-from-top-4 duration-300 z-[1000] shadow-glow ${toast.type === 'warning' ? 'border-red-500/30' : 'border-blue-500/30'}`}>
              <p className="text-[10px] font-black uppercase italic text-white tracking-[0.2em] leading-none flex items-center gap-2">
                {toast.type === 'success' ? <CheckCheck size={14} className="text-blue-500"/> : <XCircle size={14} className="text-red-500"/>}
                {toast.title}
              </p>
            </div>
          )}
        </header>
        <div className="max-w-7xl mx-auto">{renderContent()}</div>
      </main>
      
      {/* Global Activity Ticker */}
      <div className="fixed bottom-0 left-0 right-0 h-10 bg-black/90 backdrop-blur-xl border-t border-white/5 z-[60] flex items-center overflow-hidden">
        <div className="flex items-center gap-12 animate-ticker whitespace-nowrap px-12">
          {[1,2,3,4,5,6,7,8,9,10,11,12].map(i => (
            <div key={i} className="flex items-center gap-4 text-[9px] font-black uppercase italic tracking-widest text-white/20">
              <span className="text-blue-500/40 group-hover:text-blue-500 transition-colors">NODE_00{i}</span>
              <span className="opacity-50">•</span>
              <span>TX_VOL: ${(Math.random() * 1000).toFixed(2)}</span>
              <span className="opacity-50">•</span>
              <span className="text-emerald-500/40">YIELD: +{(Math.random() * 0.5).toFixed(4)}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const XCircle = ({ size, className }: any) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>
  </svg>
);

const root = document.getElementById('root');
if (root) createRoot(root).render(<App />);
