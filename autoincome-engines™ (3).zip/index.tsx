import React, { useState, useEffect, useRef, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  Activity, 
  ArrowLeft,
  Check, 
  ChevronRight, 
  Cpu, 
  Database, 
  Mail, 
  Menu, 
  Plus, 
  Settings, 
  ShieldCheck, 
  Sparkles, 
  TrendingUp, 
  X,
  Zap,
  Shield,
  Layers, 
  Layout, 
  BrainCircuit, 
  ExternalLink, 
  MicOff, 
  ArrowRight, 
  Clock, 
  Unlock, 
  Users,
  DollarSign, 
  UserPlus,
  AlertTriangle,
  BookOpen,
  LogOut,
  Banknote,
  Terminal,
  Wifi,
  Radio,
  Lock,
  User,
  RefreshCw,
  ShieldAlert,
  ShieldX,
  Trash2,
  FileText as FileIcon,
  HeartPulse,
  Receipt,
  Landmark,
  History,
  Wallet,
  Monitor,
  Command,
  Search,
  Server,
  Globe,
  Waves,
  Image as ImageIcon,
  ChevronLeft,
  Pause,
  Play,
  TrendingDown,
  Bell,
  Info,
  ArrowUpRight,
  Filter,
  Calendar,
  CheckCheck,
  Tag,
  ShieldQuestion,
  ToggleLeft,
  ToggleRight,
  Bookmark,
  Fingerprint,
  Wrench,
  FileSearch,
  RotateCcw,
  ShieldOff,
  ZapOff,
  XCircle,
  ClipboardList,
  ShieldHalf,
  Scan,
  GanttChartSquare,
  BarChart3,
  Dna,
  FileQuestion,
  Box,
  Download,
  FileJson,
  UserMinus,
  Settings2,
  Copy,
  Microscope,
  HardDrive,
  Crosshair,
  ArrowDownRight
} from 'lucide-react';
import { Type, Modality, LiveServerMessage, Blob, GenerateContentResponse, LiveConnectParameters, GenerateContentParameters } from "@google/genai";
import { apiService } from './services/apiService';

// --- Types & Interfaces ---

type Plan = 'Free Trial' | 'Starter' | 'Pro' | 'Unlimited';
type EngineStatus = 'Active' | 'Paused' | 'Optimizing' | 'Draft';
type TransactionStatus = 'Completed' | 'Processing' | 'Auditing';

interface NotificationPrefs {
  yieldMilestones: boolean;
  liquidityExits: boolean;
  gridSignals: boolean;
  securityAlerts: boolean;
}

interface UserData {
  id: string;
  name: string;
  email: string;
  password?: string;
  plan: Plan;
  role: 'User' | 'Admin'; 
  onboarded: boolean;
  balance: number;
  lifetimeYield: number;
  totalWithdrawn: number;
  notificationPrefs?: NotificationPrefs;
}

interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  status: TransactionStatus;
  method?: string;
  txHash?: string;
}

interface AuditLogEntry {
  id: string;
  timestamp: string;
  adminName: string;
  action: string;
  target: string;
  details: string;
}

interface EngineConfig {
  attackVector?: string;
  lever?: string;
  moat?: string;
  projectedRevenue?: string;
  strategyName?: string;
  prompt?: string;
  name?: string;
  visualPrompt?: string;
}

interface DeploymentResources {
  cpu: number;
  ram: number;
  region: string;
}

interface Engine {
  id: string;
  name: string;
  type: string;
  model: string;
  status: EngineStatus;
  revenue: number;
  uptime: number;
  lastSync: string;
  performance: number;
  transactions: number;
  config: EngineConfig;
  imageUrl?: string;
  history?: number[]; 
  resources?: DeploymentResources;
}

interface Article {
  id: string;
  title: string;
  category: 'Getting Started' | 'Engine Strategies' | 'Advanced Tactics' | 'Grid Economics' | 'Tutorials';
  author: string;
  publishedDate: string;
  content: string;
  featured?: boolean;
  published?: boolean;
}

interface GridNotification {
  id: string;
  timestamp: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'critical';
  read: boolean;
}

interface Anomaly {
  id: string;
  engineId: string;
  engineName: string;
  timestamp: string;
  title: string;
  description: string;
  severity: 'warning' | 'critical';
  resolved: boolean;
}

// --- Constants & Config ---

const DEFAULT_ENGINE_IMAGE = "https://images.unsplash.com/photo-1639322537228-f710d846310a?q=80&w=1200&auto=format&fit=crop";

const ENGINE_TEMPLATES = [
  { id: 'affiliate', name: 'Affiliate Magnet', description: 'Automated traffic routing to high-ticket offers using social signal nodes.', icon: TrendingUp, color: 'text-blue-500', yield: 'High Velocity', visualPrompt: 'Abstract magnetic field of glowing gold and blue data streams, high-speed routing nodes, isometric 3d tech art.' },
  { id: 'newsletter', name: 'Newsletter Engine', description: 'AI-curated content delivery with dynamic ad placement slots.', icon: Mail, color: 'text-purple-500', yield: 'Steady Growth', visualPrompt: 'Abstract pulse of violet signal waves, neural envelope silhouettes, glowing data parcels, futuristic communications grid.' },
  { id: 'digital-product', name: 'Digital Delivery', description: 'Complete sales funnel with automated license and asset delivery.', icon: Database, color: 'text-emerald-500', yield: 'Passive Max', visualPrompt: 'Emerald data monolith being sliced into segments, automated asset distribution streams, obsidian background, neon green accents.' },
  { id: 'saas-reseller', name: 'SaaS Resell Node', description: 'Automated white-label provisioning and seat management.', icon: Layers, color: 'text-orange-500', yield: 'Subscription Yield', visualPrompt: 'Interlocking orange geometric layers, provisioning logic nodes, white-label crystalline structure, glowing circuitry.' },
  { id: 'content-bot', name: 'Content Arbitrage', description: 'AI content generation node targeting low-competition search niches.', icon: Sparkles, color: 'text-pink-500', yield: 'Search Arbitrage', visualPrompt: 'Abstract shimmering pink data clouds, high-yield search nodes, neural filtering matrix, ethereal digital manifestation.' },
];

const MOCK_ARTICLES: Article[] = [
  { 
    id: 'intro-sovereignty', 
    title: 'Introduction to Sovereign Revenue', 
    category: 'Getting Started', 
    author: 'The Architect', 
    publishedDate: '2024-07-15', 
    featured: true, 
    published: true,
    content: `Sovereign Revenue represents a paradigm shift in wealth creation. By leveraging autonomous matrix nodes, architects can bypass traditional labor markets and establish self-sustaining yield streams. This protocol focuses on cognitive scalability and the removal of human latency from the profit cycle.` 
  },
  { 
    id: 'builder-guide', 
    title: 'Mastering the Architect\'s Brief', 
    category: 'Tutorials', 
    author: 'The Architect', 
    publishedDate: '2025-01-20', 
    featured: true, 
    published: true,
    content: `Architecting a successful AutoIncome Engine requires a blend of strategic intent and neural precision. The brief is the DNA of your node; if the briefing is ambiguous, the node will suffer from logic drift.` 
  },
  { 
    id: 'grid-economics-101', 
    title: 'Grid Economics: Maximizing Node Density', 
    category: 'Grid Economics', 
    author: 'Vortex', 
    publishedDate: '2025-02-01', 
    featured: false, 
    published: true,
    content: `Understanding the relationship between node latency and capital throughput is essential. By optimizing the Grid protocol, an architect can increase yield by 15-20% without increasing resource overhead. Density is not just volume; it's the intelligent arrangement of logic nodes.` 
  },
  { 
    id: 'security-protocols', 
    title: 'Fortifying Your Moat', 
    category: 'Advanced Tactics', 
    author: 'ShieldMaster', 
    publishedDate: '2025-02-05', 
    featured: false, 
    published: true,
    content: `Your economic moat is only as strong as your logic isolation. Use distinct neural paths for cross-cluster settlements to avoid single-point logical failures. Resilience is the cornerstone of sovereign wealth.` 
  },
  { 
    id: 'automation-v6', 
    title: 'Auto-Negotiation Engines', 
    category: 'Engine Strategies', 
    author: 'The Architect', 
    publishedDate: '2025-02-10', 
    featured: false, 
    published: true,
    content: `V6 engines now support real-time bid negotiation for affiliate placements. This allows for dynamic profit adjustment based on global traffic volatility. Automating the negotiation phase removes human bias and maximizes tick-by-tick yield.` 
  },
  { 
    id: 'newsletter-monetization', 
    title: 'Advanced Newsletter Arbitrage', 
    category: 'Engine Strategies', 
    author: 'Oracle', 
    publishedDate: '2025-02-12', 
    featured: false, 
    published: true,
    content: `Curating high-signal newsletters for executive niches allows for massive ad premiums. By utilizing AI-driven audience segmentation, you can deliver hyper-relevant content that yields 4x higher CTR than generic summaries.` 
  }
];

const AVAILABLE_MODELS = [
  { id: 'gemini-3-flash-preview', name: 'Gemini 3 Flash', description: 'High-speed neural routing. Ideal for rapid yield iterations.', icon: Zap },
  { id: 'gemini-3-pro-preview', name: 'Gemini 3 Pro', description: 'Deep reasoning architecture. Best for complex moats.', icon: BrainCircuit }
];

const REGIONAL_CLUSTERS = [
  { id: 'cluster-us-east', name: 'Cluster A: Virginia (US-East)', latency: '12ms' },
  { id: 'cluster-eu-west', name: 'Cluster B: Frankfurt (EU-West)', latency: '28ms' },
  { id: 'cluster-asia-east', name: 'Cluster C: Tokyo (Asia-East)', latency: '45ms' },
  { id: 'cluster-global-any', name: 'Global Dynamic Routing', latency: 'VAR' }
];

// --- Helper Functions ---

const formatCurrency = (val: any) => {
  const num = typeof val === 'number' && !isNaN(val) ? val : 0;
  return num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

function encode(bytes: Uint8Array) {
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
  }
  return buffer;
}

const generateTxHash = () => {
  const chars = '0123456789abcdef';
  let result = '0x';
  for (let i = 0; i < 40; i++) result += chars[Math.floor(Math.random() * chars.length)];
  return result;
};

const generateMockHistory = (base: number, length: number = 24) => {
  return Array.from({ length }).map(() => base + (Math.random() * 10 - 5));
};

// --- Specialized Components ---

const MetabolismTicker = ({ value, label = "Metabolism", isMain = false }: { value: number, label?: string, isMain?: boolean }) => {
  const [displayValue, setDisplayValue] = useState(value);
  const [delta, setDelta] = useState(0);
  const [showDelta, setShowDelta] = useState(false);
  const prevValue = useRef(value);

  useEffect(() => {
    if (value > prevValue.current) {
      const diff = value - prevValue.current;
      setDelta(diff);
      setShowDelta(true);
      const deltaTimer = setTimeout(() => setShowDelta(false), 2000);

      const start = displayValue;
      const end = value;
      const duration = 800;
      let startTime: number | null = null;

      const animate = (currentTime: number) => {
        if (!startTime) startTime = currentTime;
        const progress = Math.min((currentTime - startTime) / duration, 1);
        setDisplayValue(start + (end - start) * progress);
        if (progress < 1) requestAnimationFrame(animate);
      };
      requestAnimationFrame(animate);
      prevValue.current = value;
      return () => clearTimeout(deltaTimer);
    }
    prevValue.current = value;
  }, [value]);

  return (
    <div className="space-y-0.5 relative group">
      <p className={`font-black uppercase text-white/40 italic ${isMain ? 'text-[10px]' : 'text-[9px]'}`}>{label}</p>
      <div className="flex items-baseline gap-2 overflow-visible">
        <span className={`font-black italic leading-none transition-colors duration-500 ${isMain ? 'text-4xl md:text-5xl text-white' : 'text-3xl text-green-400 drop-shadow-lg'}`}>
          ${formatCurrency(displayValue)}
        </span>
        {showDelta && (
          <span className="absolute -top-2 right-0 font-mono text-[10px] font-black text-emerald-400 animate-in slide-in-from-bottom-2 fade-out duration-1000 fill-mode-forwards pointer-events-none">
            +{(delta).toFixed(4)}
          </span>
        )}
      </div>
    </div>
  );
};

const PerformanceGauge = ({ value }: { value: number }) => {
  const prevValue = useRef(value);
  const [isJittering, setIsJittering] = useState(false);

  useEffect(() => {
    if (Math.abs(value - prevValue.current) > 0.01) {
      setIsJittering(true);
      const timer = setTimeout(() => setIsJittering(false), 1000);
      prevValue.current = value;
      return () => clearTimeout(timer);
    }
  }, [value]);

  return (
    <div className="text-right flex flex-col justify-end">
      <p className="text-[9px] font-black uppercase text-white/40 italic">Efficiency</p>
      <div className="flex items-center justify-end gap-2">
        <span className={`text-lg font-black italic transition-all duration-300 ${isJittering ? 'text-blue-400 scale-110' : 'text-blue-500'} leading-none drop-shadow-lg`}>
          {value.toFixed(1)}%
        </span>
        <div className={`w-1 h-1 rounded-full ${value > 90 ? 'bg-green-500 shadow-[0_0_8px_#10b981]' : 'bg-yellow-500 shadow-[0_0_8px_#f59e0b]'} ${isJittering ? 'animate-ping' : ''}`}></div>
      </div>
    </div>
  );
};

const PerformanceTrend = ({ data, height = 32, width = 96, strokeWidth = 4, showGradient = true }: { data: number[], height?: number, width?: number, strokeWidth?: number, showGradient?: boolean }) => {
  if (!data || data.length < 2) return null;
  
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const padding = 10;
  
  const points = data.map((val, i) => {
    const x = (i / (data.length - 1)) * 100;
    const y = 100 - (((val - min) / range) * (100 - padding * 2) + padding);
    return `${x},${y}`;
  }).join(' ');

  const first = data[0];
  const last = data[data.length - 1];
  const isUp = last >= first;
  const color = isUp ? "#10b981" : "#ef4444";

  return (
    <div style={{ height, width }} className="relative overflow-visible">
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full overflow-visible">
        {showGradient && (
          <defs>
            <linearGradient id={`grad-${color.replace('#','')}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={color} stopOpacity="0.4" />
              <stop offset="100%" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
        )}
        {showGradient && (
          <path
            d={`M 0,100 L ${points} L 100,100 Z`}
            fill={`url(#grad-${color.replace('#','')})`}
            className="transition-all duration-1000"
          />
        )}
        <polyline
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeLinejoin="round"
          points={points}
          className="transition-all duration-1000 drop-shadow-[0_0_4px_rgba(16,185,129,0.5)]"
        />
      </svg>
    </div>
  );
};

const PerformanceTimeline = ({ history }: { history: number[] }) => {
  const [period, setPeriod] = useState<'Hourly' | 'Daily' | 'Weekly'>('Hourly');
  
  const data = useMemo(() => {
    if (period === 'Hourly') return history;
    if (period === 'Daily') return generateMockHistory(history[history.length - 1], 7);
    return generateMockHistory(history[history.length - 1], 12);
  }, [period, history]);

  const stats = useMemo(() => {
    const avg = data.reduce((a, b) => a + b, 0) / data.length;
    const peak = Math.max(...data);
    const low = Math.min(...data);
    return { avg, peak, low };
  }, [data]);

  return (
    <Card blueprint className="p-8 space-y-8 glass">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div className="space-y-1">
          <h3 className="text-xl font-black italic uppercase tracking-tighter text-white flex items-center gap-3">
             <Calendar size={20} className="text-blue-500" /> Performance Timeline
          </h3>
          <p className="text-[10px] font-black uppercase text-white/20 italic tracking-widest">Diagnostic Logic Fluctuations</p>
        </div>
        <div className="flex items-center gap-1 p-1 bg-white/5 rounded-xl border border-white/5">
          {['Hourly', 'Daily', 'Weekly'].map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p as any)}
              className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase italic tracking-widest transition-all ${period === p ? 'bg-blue-600 text-white shadow-glow-sm' : 'text-white/40 hover:text-white hover:bg-white/5'}`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <div className="relative h-64 w-full bg-black/20 rounded-2xl p-6 border border-white/5 group">
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[linear-gradient(rgba(255,255,255,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[size:20px_20px]"></div>
        <PerformanceTrend data={data} height={200} width={100} strokeWidth={2} />
        <div className="absolute inset-0 flex flex-col justify-between pointer-events-none p-6 py-10">
          {[1, 2, 3, 4].map(i => <div key={i} className="w-full border-t border-white/[0.03]"></div>)}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        {[
          { label: 'Peak Signal', value: `${stats.peak.toFixed(2)}%`, color: 'text-emerald-500' },
          { label: 'Mean Drift', value: `${stats.avg.toFixed(2)}%`, color: 'text-blue-500' },
          { label: 'Floor Level', value: `${stats.low.toFixed(2)}%`, color: 'text-red-500' }
        ].map((s, i) => (
          <div key={i} className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-1">
            <p className="text-[9px] font-black uppercase text-white/30 italic">{s.label}</p>
            <p className={`text-xl font-black italic ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>
    </Card>
  );
};

const Logo = ({ size = 40, className = "", animate = false }: { size?: number, className?: string, animate?: boolean }) => (
  <div className={`flex items-center gap-3 ${className}`}>
    <div className="relative group">
      <div className={`absolute inset-0 bg-blue-600 blur-lg opacity-40 group-hover:opacity-80 transition-opacity ${animate ? 'animate-pulse' : ''}`}></div>
      <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="relative drop-shadow-2xl overflow-visible">
        <path d="M50 5L10 25V75L50 95L90 75V25L50 5Z" fill="#0070f3" fillOpacity="0.1" stroke="#0070f3" strokeWidth="4" className={animate ? 'animate-[pulse_4s_infinite]' : ''}/>
        <circle cx="50" cy="50" r="22" stroke="#0070f3" strokeWidth="1" strokeDasharray="4 4" className="animate-[spin_15s_linear_infinite]"/>
        <path d="M35 50H65M50 35V65" stroke="white" strokeWidth="4" strokeLinecap="round" className={animate ? 'animate-[bounce_2s_infinite]' : ''}/>
      </svg>
    </div>
    <div className="flex flex-col leading-none">
      <span className="text-white text-xl font-black italic tracking-tighter uppercase">AutoIncome</span>
      <span className="text-blue-500 text-[10px] font-black uppercase tracking-[0.3em]">Engines™</span>
    </div>
  </div>
);

const Button = ({ children, onClick, variant = 'primary', className = '', icon: Icon, disabled = false, size = 'md', type = 'button', loading = false }: any) => {
  const base = "flex items-center justify-center gap-2 rounded-lg font-bold transition-all duration-300 active:scale-95 disabled:opacity-50 disabled:active:scale-100 relative overflow-hidden group whitespace-nowrap";
  const sizes: any = { sm: "px-4 py-2 text-sm", md: "px-6 py-3 text-base", lg: "px-8 py-4 text-lg" };
  const variants: any = {
    primary: "bg-[#0070f3] hover:bg-blue-500 text-white shadow-glow",
    secondary: "bg-white/10 hover:bg-white/20 text-white",
    outline: "border border-white/20 hover:border-white/40 text-white",
    ghost: "text-white/60 hover:text-white hover:bg-white/5",
    danger: "bg-red-500/10 text-red-500 border border-red-500/20",
    success: "bg-green-600 hover:bg-green-500 text-white",
    gold: "bg-[#b8860b]/20 hover:bg-[#b8860b]/40 border border-[#b8860b]/30 text-[#ffd700]"
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled || loading} className={`${base} ${sizes[size]} ${variants[variant]} ${className}`}>
      {loading ? (<Activity size={18} className="animate-spin" />) : Icon && (<Icon size={size === 'sm' ? 16 : 18} />)}
      {children}
    </button>
  );
};

const Card = ({ children, className = '', hover = false, onClick, blueprint = false, image, ...props }: any) => (
  <div 
    onClick={onClick} 
    className={`glass rounded-2xl p-6 transition-all duration-300 relative overflow-hidden group
      ${hover ? 'hover:border-blue-500/40 hover:bg-white/5 hover:-translate-y-1.5 hover:scale-[1.01] hover:shadow-glow-sm' : ''} 
      ${className} 
      ${onClick ? 'cursor-pointer active:scale-[0.98]' : ''}`} 
    {...props}
  >
    {blueprint && <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:20px_20px]"></div>}
    {image && (
      <>
        <div className="absolute inset-0 z-0 opacity-20 group-hover:opacity-40 pointer-events-none overflow-hidden transition-opacity duration-500">
          <img src={image} className="w-full h-full object-cover animate-ken-burns group-hover:scale-110 transition-transform duration-700" alt="" />
        </div>
        <div className="absolute inset-0 z-0 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none"></div>
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden opacity-30 group-hover:opacity-60 transition-opacity duration-500">
            <div className="absolute inset-y-0 -inset-x-full w-[50%] bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer-sweep"></div>
        </div>
        <div className="absolute inset-0 z-0 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-[linear-gradient(rgba(0,112,243,0.05)_1px,transparent_1px)] bg-[length:100%_4px] mix-blend-overlay"></div>
      </>
    )}
    <div className="relative z-10 h-full">{children}</div>
  </div>
);

const Badge = ({ children, variant = 'info', className = '', live = false, onClick }: any) => {
  const variants: any = {
    success: "bg-green-500/10 text-green-400 border border-green-500/20",
    warning: "bg-yellow-500/10 text-yellow-400 border border-green-500/20",
    info: "bg-blue-500/10 text-blue-400 border border-blue-500/20",
    neutral: "bg-white/5 text-white/50 border border-white/10",
    danger: "bg-red-500/10 text-red-400 border border-red-500/20",
    gold: "bg-[#ffd700]/10 text-[#ffd700] border border-[#ffd700]/20"
  };
  return (<button onClick={onClick} disabled={!onClick} className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-[10px] uppercase tracking-widest font-black italic transition-all ${onClick ? 'hover:scale-105 active:scale-95' : ''} ${variants[variant]} ${className}`}>
    {live && <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>}
    {children}
  </button>);
};

// --- Network topology visualizer ---
const NetworkTopology = ({ nodeCount }: { nodeCount: number }) => {
  return (
    <div className="relative h-48 w-full bg-black/40 rounded-2xl overflow-hidden border border-white/5 group">
      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-from)_0%,_transparent_70%)] from-blue-600"></div>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative w-32 h-32">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-8 h-8 bg-blue-600 rounded-full animate-pulse shadow-glow"></div>
            <div className="absolute w-24 h-24 border border-blue-600/20 rounded-full animate-[spin_10s_linear_infinite]"></div>
            <div className="absolute w-32 h-32 border border-blue-600/10 rounded-full animate-[spin_15s_linear_infinite_reverse]"></div>
          </div>
          {Array.from({ length: Math.max(3, nodeCount) }).map((_, i) => (
            <div 
              key={i} 
              className="absolute w-2 h-2 bg-blue-400 rounded-full shadow-glow-sm"
              style={{
                top: '50%',
                left: '50%',
                transform: `rotate(${i * (360 / Math.max(3, nodeCount))}deg) translate(50px) rotate(-${i * (360 / Math.max(3, nodeCount))}deg)`
              }}
            >
              <div className="absolute inset-[-10px] border-t border-blue-500/20 rounded-full animate-ping"></div>
            </div>
          ))}
        </div>
      </div>
      <div className="absolute bottom-4 left-4 flex items-center gap-2">
        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
        <span className="text-[9px] font-black uppercase tracking-[0.2em] text-white/40 italic">Grid Link: Synchronized</span>
      </div>
    </div>
  );
};

// --- Storage Utils ---
const saveEnginesToStorage = (engines: Engine[]) => {
  const stripped = engines.map(({ imageUrl, ...rest }) => ({ ...rest, imageUrl }));
  localStorage.setItem('autoincome_engines', JSON.stringify(stripped));
};

// --- Handshake ---
const SystemHandshake = ({ onComplete }: { onComplete: () => void }) => {
  const [logs, setLogs] = useState<string[]>([]);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const sequence = [
      "AUTHENTICATING ARCHITECT CREDENTIALS...",
      "HANDSHAKE ESTABLISHED VIA NEURAL-LINK-7",
      "DECRYPTING SOVEREIGNTY PROTOCOLS...",
      "FETCHING ACTIVE NODE TOPOLOGY...",
      "SYNCING TREASURY BALANCE (USD/BTC)...",
      "GRID ACCESS GRANTED. WELCOME BACK."
    ];
    let i = 0;
    const interval = setInterval(() => {
      if (i < sequence.length) {
        setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${sequence[i]}`]);
        i++;
      } else {
        clearInterval(interval);
        setTimeout(onComplete, 1000);
      }
    }, 400);
    return () => clearInterval(interval);
  }, [onComplete]);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [logs]);

  return (
    <div className="fixed inset-0 z-[9999] bg-[#050505] flex items-center justify-center p-8">
      <div className="w-full max-w-2xl space-y-12 text-center animate-in fade-in zoom-in-95 duration-1000">
        <Logo size={80} animate className="justify-center" />
        <div ref={logRef} className="h-48 bg-black/40 border border-blue-600/20 rounded-xl p-8 font-mono text-left text-blue-500 text-xs overflow-y-auto scrollbar-hide glass">
          {logs.map((l, i) => <div key={i} className="animate-in fade-in slide-in-from-left-4 mb-2">{l}</div>)}
          <div className="w-2 h-4 bg-blue-500 animate-pulse inline-block align-middle ml-1"></div>
        </div>
      </div>
    </div>
  );
};

// --- Login & Sign Up ---
const LoginScreen = ({ onLogin, onSignUp, isGridEmpty, onPurge }: { onLogin: (email: string, pass: string) => string | undefined, onSignUp: (name: string, email: string, pass: string) => string | undefined, isGridEmpty: boolean, onPurge: () => void }) => {
  const [mode, setMode] = useState<'login' | 'signup'>(isGridEmpty ? 'signup' : 'login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setTimeout(() => {
      let err;
      if (mode === 'login') {
        err = onLogin(email, password);
      } else {
        err = onSignUp(name, email, password);
      }
      if (err) { setError(err); setLoading(false); }
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-[#050505] flex flex-col items-center justify-center p-8 relative overflow-hidden">
      <div className="absolute inset-0 blueprint-bg opacity-[0.05]"></div>
      <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:40px_40px] animate-grid-pulse"></div>
      <div className="relative z-10 w-full max-w-md">
        <Card className="p-10 space-y-8 glass" blueprint>
          <div className="text-center space-y-4">
            <Logo size={60} className="justify-center" animate />
            <h1 className="text-2xl font-black italic uppercase text-white tracking-tighter">Grid Access Terminal</h1>
            <p className="text-sm text-white/40 italic">
              {isGridEmpty ? 'The seat of the Lead Architect is vacant. Initialize Identity.' : (mode === 'login' ? 'Authenticate to architect sovereignty.' : 'Initialize your architect identity.')}
            </p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-5">
            {mode === 'signup' && (
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-white/30 italic tracking-widest">Architect Alias</label>
                <div className="relative">
                  <User size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20"/>
                  <input type="text" value={name} onChange={e => setName(e.target.value)} required className="w-full h-12 bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 text-white focus:outline-none focus:border-blue-600 transition-all" placeholder="e.g. CyberNode_01" />
                </div>
              </div>
            )}
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-white/30 italic tracking-widest">Uplink Email</label>
              <div className="relative">
                <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20"/>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full h-12 bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 text-white focus:outline-none focus:border-blue-600 transition-all" placeholder="architect@grid.io" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-white/30 italic tracking-widest">Secret Passphrase</label>
              <div className="relative">
                <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20"/>
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} required className="w-full h-12 bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 text-white focus:outline-none focus:border-blue-600 transition-all" placeholder="••••••••" />
              </div>
            </div>
            {error && <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-xs text-center italic flex items-center gap-2 justify-center"><AlertTriangle size={14}/>{error}</div>}
            <Button type="submit" size="lg" className="w-full" loading={loading} icon={mode === 'login' ? Unlock : UserPlus}>
              {loading ? (mode === 'login' ? 'Authenticating...' : 'Initializing...') : (mode === 'login' ? 'Access Grid' : 'Initialize Identity')}
            </Button>
          </form>
          <div className="text-center pt-2 space-y-4">
            {!isGridEmpty && (
                <button onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); }} className="text-xs font-black italic uppercase text-white/40 hover:text-blue-500 transition-colors tracking-widest block w-full">
                {mode === 'login' ? "Need an account? Create Identity" : "Already registered? Authenticate"}
                </button>
            )}
            <button onClick={onPurge} className="text-[9px] font-black uppercase text-white/10 hover:text-red-500 transition-colors tracking-widest block w-full">
              Reset Grid Session (Legacy Cleanup)
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
};

// --- Ticker ---
const GlobalActivityTicker = () => {
  const [messages, setMessages] = useState<string[]>([]);
  useEffect(() => {
    const news = [
      "NODE-422 yield spike: +12% performance increase in Hong Kong cluster.",
      "New Architect joined from San Francisco. Matrix expansion ongoing.",
      "Freedom Wheels™ strategy update: 'Momentum Arbitrage' nodes optimized for Q4 signals.",
      "Treasury withdrawal of $2,440.00 processed successfully.",
      "Neural uplink latency reduced by 40ms in European data center."
    ];
    setMessages([...news, ...news]);
  }, []);
  return (
    <div className="fixed bottom-0 left-0 right-0 h-8 bg-black/80 border-t border-white/5 backdrop-blur-md z-[100] flex items-center overflow-hidden">
      <div className="flex items-center gap-4 px-4 h-full border-r border-white/10 bg-blue-600/20 whitespace-nowrap">
        <Wifi size={14} className="text-blue-500 animate-pulse" />
        <span className="text-[10px] font-black uppercase tracking-widest text-blue-500">Global Feed</span>
      </div>
      <div className="flex-1 whitespace-nowrap flex animate-[scroll_60s_linear_infinite]">
        {messages.map((m, i) => (
          <span key={i} className="px-12 text-[10px] font-bold text-white/40 italic flex items-center gap-2">
            <Radio size={10} className="text-white/20" /> {m}
          </span>
        ))}
      </div>
    </div>
  );
};

// --- Profile & Settings ---
const ProfileSettings = ({ user, onUpdate, onCancel }: { user: UserData, onUpdate: (u: Partial<UserData>) => void, onCancel: () => void }) => {
    const [name, setName] = useState(user.name);
    const [email, setEmail] = useState(user.email);
    const [pass, setPass] = useState(user.password || '');
    const [saving, setSaving] = useState(false);
    const [success, setSuccess] = useState(false);
    
    const [prefs, setPrefs] = useState<NotificationPrefs>(user.notificationPrefs || {
      yieldMilestones: true,
      liquidityExits: true,
      gridSignals: true,
      securityAlerts: true
    });

    const handleSave = () => {
        setSaving(true);
        setTimeout(() => {
            onUpdate({ name, email, password: pass, notificationPrefs: prefs });
            setSaving(false);
            setSuccess(true);
            setTimeout(() => setSuccess(false), 3000);
        }, 1500);
    };

    const togglePref = (key: keyof NotificationPrefs) => {
      setPrefs(prev => ({ ...prev, [key]: !prev[key] }));
    };

    const PrefRow = ({ label, desc, icon: Icon, active, onToggle }: any) => (
      <div className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/5 hover:border-white/10 transition-all group">
        <div className="flex items-center gap-4">
          <div className={`p-2 rounded-lg ${active ? 'bg-blue-600/20 text-blue-500' : 'bg-white/5 text-white/20'}`}>
            <Icon size={18} />
          </div>
          <div>
            <p className="text-[10px] font-black uppercase text-white italic tracking-widest">{label}</p>
            <p className="text-[9px] text-white/30 italic">{desc}</p>
          </div>
        </div>
        <button onClick={onToggle} className={`transition-all ${active ? 'text-blue-500' : 'text-white/20'}`}>
          {active ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
        </button>
      </div>
    );

    return (
        <div className="max-w-3xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-24">
            <div className="flex items-center justify-between">
                <h1 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter leading-none text-white">Architect Profile</h1>
                <Button variant="outline" onClick={onCancel} icon={ArrowLeft}>Back</Button>
            </div>
            
            <div className="grid grid-cols-1 gap-8">
              <Card blueprint className="space-y-8 p-10 glass">
                  <h3 className="text-xl font-black italic uppercase text-white border-b border-white/5 pb-4">Architect Credentials</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-2">
                          <label className="text-xs font-black uppercase text-white/40 tracking-widest italic">Alias / Name</label>
                          <div className="relative">
                              <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20"/>
                              <input value={name} onChange={e => setName(e.target.value)} className="w-full h-12 bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 focus:border-blue-600 outline-none text-white transition-all"/>
                          </div>
                      </div>
                      <div className="space-y-2">
                          <label className="text-xs font-black uppercase text-white/40 tracking-widest italic">Uplink Email</label>
                          <div className="relative">
                              <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20"/>
                              <input value={email} onChange={e => setEmail(e.target.value)} className="w-full h-12 bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 focus:border-blue-600 outline-none text-white transition-all"/>
                          </div>
                      </div>
                  </div>
              </Card>

              <Card blueprint className="space-y-8 p-10 glass">
                  <div className="flex items-center gap-3 border-b border-white/5 pb-4">
                    <Bell size={20} className="text-blue-500" />
                    <h3 className="text-xl font-black italic uppercase text-white">Notification Uplink</h3>
                  </div>
                  <p className="text-xs text-white/40 italic">Configure automated communication protocols for Treasury Hub events.</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <PrefRow 
                      label="Yield Milestones" 
                      desc="Get notified when grid nodes hit liquidity targets." 
                      icon={TrendingUp} 
                      active={prefs.yieldMilestones}
                      onToggle={() => togglePref('yieldMilestones')}
                    />
                    <PrefRow 
                      label="Liquidity Exits" 
                      desc="Confirmations for capital withdrawal requests." 
                      icon={Banknote} 
                      active={prefs.liquidityExits}
                      onToggle={() => togglePref('liquidityExits')}
                    />
                    <PrefRow 
                      label="Grid Signals" 
                      desc="Real-time alerts for engine performance shifts." 
                      icon={Radio} 
                      active={prefs.gridSignals}
                      onToggle={() => togglePref('gridSignals')}
                    />
                    <PrefRow 
                      label="Security Overrides" 
                      desc="Critical alerts for privileged role changes." 
                      icon={ShieldAlert} 
                      active={prefs.securityAlerts}
                      onToggle={() => togglePref('securityAlerts')}
                    />
                  </div>
              </Card>
            </div>

            {success && (
              <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg text-green-400 text-xs italic text-center animate-in zoom-in-95">
                Architect Identity and Communication Protocols Synchronized.
              </div>
            )}
            
            <Button onClick={handleSave} loading={saving} icon={ShieldCheck} className="w-full py-6">Update Global Configuration</Button>
        </div>
    );
};

// --- Architect Uplink ---
const LiveArchitectUplink = ({ onExit, addNotification }: { onExit: () => void, addNotification: (title: string, message: string, type: GridNotification['type']) => void }) => {
  const [isActive, setIsActive] = useState(false);
  const [transcription, setTranscription] = useState<string[]>([]);
  const [currentOutput, setCurrentOutput] = useState("");
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const nextStartTimeRef = useRef<number>(0);

  const startSession = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      const sessionPromise = apiService.connectLive({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            if (!audioContextRef.current) return;
            const source = audioContextRef.current.createMediaStreamSource(stream);
            const scriptProcessor = audioContextRef.current.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob: Blob = { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
              sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current.destination);
            setIsActive(true);
          },
          onmessage: async (msg: LiveServerMessage) => {
            if (msg.serverContent?.interrupted) {
              for (const source of sourcesRef.current.values()) {
                source.stop();
                sourcesRef.current.delete(source);
              }
              nextStartTimeRef.current = 0;
            }
            if (msg.serverContent?.outputTranscription) {
              const text = msg.serverContent.outputTranscription.text;
              setCurrentOutput(prev => prev + text);
            }
            if (msg.serverContent?.turnComplete) { 
              setTranscription(prev => [...prev, currentOutput]); 
              setCurrentOutput(""); 
            }
            const modelTurn = msg.serverContent?.modelTurn;
            const audioBase64 = modelTurn?.parts?.[0]?.inlineData?.data;
            
            if (audioBase64 && outputAudioContextRef.current) {
              const ctx = outputAudioContextRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const buffer = await decodeAudioData(decode(audioBase64), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }
          },
          onerror: (e) => {
            console.error("Live Error", e)
            addNotification("Uplink Critical Error", `Live connection failed unexpectedly. Please sever and re-initiate.`, 'critical');
          },
          onclose: () => setIsActive(false),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          systemInstruction: 'You are the Lead Architect of the AutoIncome Engine grid. Provide strategic sovereignty advice.'
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err: any) { 
      console.error(err); 
      addNotification("Uplink Failed", `Could not get microphone access: ${err.message}`, 'critical');
    }
  };

  const stopSession = () => {
    if (sessionRef.current) sessionRef.current.close();
    if (audioContextRef.current) audioContextRef.current.close();
    if (outputAudioContextRef.current) outputAudioContextRef.current.close();
    setIsActive(false);
  };
  useEffect(() => () => stopSession(), []);

  return (
    <div className="max-w-4xl mx-auto py-12 space-y-8 animate-in fade-in duration-500 pb-16 px-4">
      <div className="flex items-center justify-between border-b border-white/5 pb-6">
        <h1 className="text-4xl font-black italic uppercase text-white tracking-tighter">Architect Hub</h1>
        <button onClick={onExit} className="p-2 hover:bg-white/5 rounded-full text-white/40 hover:text-white transition-colors"><X size={24} /></button>
      </div>
      <Card className="h-[500px] flex flex-col glass" blueprint>
        <div className="p-6 border-b border-white/5 flex items-center gap-4">
          <div className={`p-3 rounded-xl ${isActive ? 'bg-blue-600 shadow-glow' : 'bg-white/5'}`}><BrainCircuit size={24} /></div>
          <span className="text-xl font-black italic uppercase text-white tracking-tighter">{isActive ? 'Uplink Established' : 'Neural Standby'}</span>
        </div>
        <div className="flex-1 p-8 overflow-y-auto space-y-4 font-mono text-sm scrollbar-hide bg-black/40">
          {transcription.map((t, i) => <p key={i} className="text-white/80 italic animate-in fade-in slide-in-from-left-2">{t}</p>)}
          {currentOutput && <p className="text-blue-400 italic animate-pulse">{currentOutput}</p>}
          {transcription.length === 0 && !currentOutput && (
            <div className="h-full flex flex-col items-center justify-center opacity-20 space-y-4">
              <MicOff size={48} />
              <p className="text-xs uppercase tracking-widest font-black italic">Neural uplink quiet.</p>
            </div>
          )}
        </div>
        <div className="p-6 bg-black flex justify-center border-t border-white/5">
          {!isActive ? <Button size="lg" className="w-full" onClick={startSession} icon={Zap}>Initiate Uplink</Button> : <Button variant="danger" size="lg" className="w-full" onClick={stopSession} icon={MicOff}>Sever Connection</Button>}
        </div>
      </Card>
    </div>
  );
};

// --- Decommissioning Components ---

const DecommissionNodeModal = ({ 
  engine, 
  onConfirm, 
  onCancel 
}: { 
  engine: Engine, 
  onConfirm: () => void, 
  onCancel: () => void 
}) => {
  const [isExplicitlyConfirmed, setIsExplicitlyConfirmed] = useState(false);

  return (
    <div className="fixed inset-0 z-[2000] bg-black/90 backdrop-blur-3xl flex items-center justify-center p-6 animate-in fade-in duration-300">
      <div className="w-full max-w-md relative">
        <Card blueprint className="p-10 space-y-8 shadow-3xl border-red-500/20 glass text-center">
          <div className="flex flex-col items-center gap-4">
             <div className="p-4 rounded-full bg-red-500/10 text-red-500 animate-pulse">
                <Trash2 size={48} />
             </div>
             <h3 className="text-2xl font-black italic uppercase tracking-tighter text-white leading-tight">Decommission Node</h3>
          </div>
          
          <div className="space-y-6">
            <div className="p-4 bg-red-500/5 border border-red-500/20 rounded-xl space-y-4">
              <p className="text-sm text-white/80 italic leading-relaxed">
                CRITICAL: You are initiating the permanent decommissioning of node <span className="text-red-400 font-bold">"{engine.name}"</span>.
              </p>
              
              <section className="text-left space-y-3">
                 <h4 className="text-[10px] font-black uppercase text-red-400 tracking-widest italic flex items-center gap-2"><AlertTriangle size={14} /> System Implications</h4>
                 <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-[10px] text-white/40 italic"><ZapOff size={12} className="text-red-500" /> Immediate termination of yield generation logic.</li>
                    <li className="flex items-center gap-2 text-[10px] text-white/40 italic"><ShieldOff size={12} className="text-red-500" /> Permanent deletion of node configuration DNA.</li>
                    <li className="flex items-center gap-2 text-[10px] text-white/40 italic"><Database size={12} className="text-red-500" /> Purging of neural telemetry and history logs.</li>
                    <li className="flex items-center gap-2 text-[10px] text-white/40 italic"><XCircle size={12} className="text-red-500" /> Irreversible removal from Grid Registry.</li>
                 </ul>
              </section>
            </div>

            <div 
              onClick={() => setIsExplicitlyConfirmed(!isExplicitlyConfirmed)}
              className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center gap-4 text-left ${isExplicitlyConfirmed ? 'bg-red-500/10 border-red-500 shadow-glow-sm' : 'bg-white/5 border-white/10 hover:border-white/20'}`}
            >
              <div className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${isExplicitlyConfirmed ? 'bg-red-600 border-red-400' : 'border-white/20'}`}>
                {isExplicitlyConfirmed && <Check size={14} />}
              </div>
              <p className="text-[10px] font-black uppercase text-white/60 italic tracking-widest leading-none">
                I acknowledge permanent loss of node DNA
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <Button onClick={onConfirm} variant="danger" size="lg" className="w-full h-14" icon={Trash2} disabled={!isExplicitlyConfirmed}>Confirm Decommissioning</Button>
            <Button onClick={onCancel} variant="outline" className="w-full" icon={X}>Abort Protocol</Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

// --- Engine Builder Components ---

function sanitizeAndParseJson(rawText: string | undefined): any {
    if (!rawText || typeof rawText !== 'string') throw new Error("NEURAL_EMPTY_SIGNAL: Undefined signal.");
    let sanitizedText = rawText.trim();
    const jsonMatch = sanitizedText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("SCHEMA_VIOLATION: Response does not contain valid structural DNA.");
    sanitizedText = jsonMatch[0];
    try { return JSON.parse(sanitizedText); } 
    catch (e) { throw new Error(`SYNTACTIC_NOISE: Failed to parse neural config.`); }
}

const DeploymentConfirmationModal = ({ 
  config, 
  onConfirm, 
  onCancel,
  imageUrl,
  resources
}: { 
  config: { name: string, type: string, model: string, brief: string, yieldProfile: string, templateDesc: string }, 
  onConfirm: () => void, 
  onCancel: () => void,
  imageUrl?: string,
  resources?: DeploymentResources
}) => {
  const [authorized, setAuthorized] = useState(false);

  return (
    <div className="fixed inset-0 z-[2000] bg-black/95 backdrop-blur-3xl flex items-center justify-center p-6 animate-in fade-in duration-300">
      <div className="w-full max-w-4xl relative overflow-y-auto max-h-[95vh] scrollbar-hide">
        <Card blueprint className="p-8 md:p-12 space-y-10 shadow-3xl border-blue-500/20 glass overflow-hidden">
          {/* Decorative Elements */}
          <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none">
            <Scan size={320} className="text-blue-500" />
          </div>

          <header className="text-center space-y-6 relative z-10">
            <div className="w-20 h-20 rounded-[2.5rem] bg-blue-600/10 flex items-center justify-center border border-blue-500/20 mx-auto text-blue-500 animate-pulse shadow-glow-sm">
               <Fingerprint size={40} />
            </div>
            <div className="space-y-2">
              <h2 className="text-4xl font-black italic uppercase tracking-tighter text-white leading-none">Final Node Validation</h2>
              <p className="text-blue-500/60 text-[10px] font-black uppercase tracking-[0.4em] italic">Architectural Commitment Phase</p>
            </div>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 relative z-10">
            {/* Visual Manifestation */}
            <div className="space-y-6">
               <div className="flex items-center gap-3 border-b border-white/10 pb-3">
                  <ImageIcon size={16} className="text-purple-500" />
                  <h3 className="text-[11px] font-black uppercase text-white tracking-widest italic">Visual Manifestation</h3>
               </div>
               <div className="aspect-video w-full rounded-2xl border border-white/10 overflow-hidden bg-black/40 relative group">
                  <img src={imageUrl || DEFAULT_ENGINE_IMAGE} className="w-full h-full object-cover animate-ken-burns" alt="Node Representation" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                     <Badge variant="gold" className="text-[8px]">Unique Neural Artifact</Badge>
                  </div>
               </div>
               <div className="grid grid-cols-1 gap-4">
                  <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1 group hover:border-blue-500/30 transition-all">
                      <p className="text-[9px] font-black uppercase text-white/30 italic">Node Identifier</p>
                      <p className="text-lg font-black italic text-white uppercase truncate">{config.name}</p>
                  </div>
               </div>
            </div>

            {/* Sector 2: Performance Core */}
            <div className="space-y-6">
               <div className="flex items-center gap-3 border-b border-white/10 pb-3">
                  <Activity size={16} className="text-emerald-500" />
                  <h3 className="text-[11px] font-black uppercase text-white tracking-widest italic">Neural Engine Specs</h3>
               </div>
               <div className="grid grid-cols-1 gap-4">
                  <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2">
                      <p className="text-[9px] font-black uppercase text-white/30 italic">Neural Core Processor</p>
                      <p className="text-sm font-bold italic text-white uppercase">{config.model}</p>
                      <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                         <div className="h-full bg-blue-600 w-3/4 animate-pulse"></div>
                      </div>
                  </div>
                  {resources && (
                    <div className="p-5 rounded-2xl bg-blue-600/5 border border-blue-500/20 space-y-2">
                        <p className="text-[9px] font-black uppercase text-blue-400 italic">Advanced Infrastructure</p>
                        <div className="flex flex-wrap gap-x-4 gap-y-2">
                           <span className="text-[10px] text-white/60 italic font-bold">CPU: {resources.cpu} Cores</span>
                           <span className="text-[10px] text-white/60 italic font-bold">RAM: {resources.ram} GB</span>
                           <span className="text-[10px] text-white/60 italic font-bold">Cluster: {REGIONAL_CLUSTERS.find(c => c.id === resources.region)?.name || 'Unknown'}</span>
                        </div>
                    </div>
                  )}
                  <div className="p-5 rounded-2xl bg-emerald-500/5 border border-emerald-500/20 space-y-2">
                      <p className="text-[9px] font-black uppercase text-emerald-400/60 italic">Projected Revenue</p>
                      <div className="flex items-center gap-2">
                         <TrendingUp size={16} className="text-emerald-500" />
                         <p className="text-lg font-black italic text-emerald-400 uppercase leading-none">{config.yieldProfile}</p>
                      </div>
                  </div>
               </div>
            </div>
          </div>

          {/* Sector 3: Strategic Brief (Full Width) */}
          <div className="space-y-6 relative z-10">
             <div className="flex items-center gap-3 border-b border-white/10 pb-3">
                <Dna size={16} className="text-blue-500" />
                <h3 className="text-[11px] font-black uppercase text-white tracking-widest italic">Architect's Strategic Brief</h3>
             </div>
             <div className="p-6 rounded-3xl bg-black/60 border border-white/10 space-y-4 shadow-inner relative group">
                <Terminal size={14} className="absolute top-6 right-6 text-blue-500/20 group-hover:text-blue-500/40 transition-colors" />
                <div className="max-h-36 overflow-y-auto pr-4 scrollbar-hide">
                  <p className="text-[13px] text-white/80 font-mono italic leading-relaxed whitespace-pre-wrap">
                    {config.brief ? `> ${config.brief.replace(/\n/g, '\n> ')}` : "> INITIALIZING STANDARD AUTONOMOUS LOGIC PROTOCOL...\n> WAIT FOR NEURAL HANDSHAKE..."}
                  </p>
                </div>
                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                   <p className="text-[9px] text-white/20 italic">{config.templateDesc}</p>
                   <span className="text-[8px] font-black uppercase text-blue-500/40 tracking-[0.2em] italic animate-pulse">Encryption: RSA-4096</span>
                </div>
             </div>
          </div>

          {/* Explicit Authorization Interaction */}
          <footer className="space-y-8 pt-4 relative z-10">
            <div 
              onClick={() => setAuthorized(!authorized)}
              className={`p-6 rounded-3xl border transition-all cursor-pointer flex items-center gap-6 group relative overflow-hidden ${authorized ? 'bg-blue-600/10 border-blue-500 shadow-glow-sm' : 'bg-white/5 border-white/10 hover:border-white/20'}`}
            >
              {authorized && <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-transparent animate-shimmer-sweep"></div>}
              <div className={`w-8 h-8 rounded-xl border flex items-center justify-center transition-all ${authorized ? 'bg-blue-600 border-blue-400 text-white rotate-0' : 'border-white/20 -rotate-45'}`}>
                {authorized ? <Check size={18} /> : <div className="w-3 h-3 rounded-sm border border-white/30"></div>}
              </div>
              <div className="space-y-1">
                <p className="text-xs font-black uppercase italic tracking-widest text-white/60 group-hover:text-white transition-colors leading-none">
                  Explicit Architectural Authorization
                </p>
                <p className="text-[9px] text-white/20 italic">I confirm the parameters and authorize node initialization into the AutoIncome Grid.</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
               <Button 
                onClick={onConfirm} 
                size="lg" 
                className="flex-1 h-20 shadow-glow text-xl font-black italic uppercase tracking-tighter" 
                icon={ShieldCheck} 
                disabled={!authorized}
               >
                 Authorize Grid Uplink
               </Button>
               <Button onClick={onCancel} variant="outline" className="h-20 px-10 text-xs font-black uppercase tracking-widest italic opacity-40 hover:opacity-100 transition-opacity">Abort Deployment</Button>
            </div>
          </footer>
        </Card>
      </div>
    </div>
  );
};

interface BuilderError {
  title: string;
  message: string;
  code: string;
  failurePoint: string;
  remedy: string;
  technicalLogs?: string[];
}

const EngineBuilder = ({ isAdmin, onDeploy, onCancel, templateIcons, addNotification }: { isAdmin: boolean, onDeploy: (e: Engine) => void, onCancel: () => void, templateIcons: Record<string, string>, addNotification: (title: string, message: string, type: GridNotification['type']) => void }) => {
  const [step, setStep] = useState(1);
  const [template, setTemplate] = useState<any>(null);
  const [model, setModel] = useState(AVAILABLE_MODELS[0].id);
  const [brief, setBrief] = useState("");
  const [customName, setCustomName] = useState("");
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [error, setError] = useState<BuilderError | null>(null);

  // Advanced Provisioning State (Admin Only)
  const [cpuCount, setCpuCount] = useState(4);
  const [ramGB, setRamGB] = useState(8);
  const [targetRegion, setTargetRegion] = useState(REGIONAL_CLUSTERS[0].id);
  
  // Storage for AI generated results
  const [synthesizedConfig, setSynthesizedConfig] = useState<EngineConfig | null>(null);
  const [synthesizedImage, setSynthesizedImage] = useState<string | undefined>(undefined);

  const handleSynthesize = async () => {
    setIsSynthesizing(true);
    setError(null);
    setLogs(["> ARCHITECTURE PROTOCOL INITIATED..."]);
    
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      const errorPayload = {
        title: "Uplink Protocol Failure",
        message: "No valid API key detected in the execution context. Grid communication impossible.",
        code: "ERR_AUTH_VACUUM",
        failurePoint: "INITIAL_HANDSHAKE",
        remedy: "Initialize system environment variables and secure the Architect's API key before re-attempting deployment."
      };
      setError(errorPayload);
      addNotification(errorPayload.title, errorPayload.message, 'critical');
      setIsSynthesizing(false);
      return;
    }

    let configData: EngineConfig = {};
    let synthesizedUrl: string | undefined = undefined;

    try {
        setLogs(prev => [...prev, "> Handshaking with neural core for logic topology..."]);
        const resp: GenerateContentResponse = await apiService.generateStrategy(model, customName, brief, template.name)
        .catch(e => {
            throw { 
              title: "Neural Core Uplink Error", 
              message: "Failed to establish a stable logic channel with the neural processor. Signal lost.", 
              code: "ERR_CORE_DISCONNECT",
              failurePoint: "NEURAL_SYNTHESIS_PHASE",
              remedy: "Verify network topology stability and API limits. Re-handshake with the core model.",
              originalError: e
            };
        });
        
        const text = resp.text;
        if (!text) throw { 
          title: "Logic DNA Nullified", 
          message: "The neural core returned an empty logic signal. Architecture rejected.", 
          code: "ERR_EMPTY_DNA",
          failurePoint: "SYNTACTIC_DECODING",
          remedy: "The strategic briefing may be too ambiguous. Provide more specific operational constraints in the briefing DNA."
        };

        try {
          configData = sanitizeAndParseJson(text);
        } catch (e: any) {
          throw {
            title: "DNA Parsing Violation",
            message: "The synthesized strategy DNA contains logical contradictions or syntax noise.",
            code: "ERR_JSON_CORRUPTION",
            failurePoint: "DATA_STRUCT_DECODING",
            remedy: "The neural core drifted out of schema bounds. Recalibrate briefing specificity and retry node deployment.",
            originalError: e
          };
        }
        
        const finalName = customName.trim();
        setLogs(prev => [...prev, `> Node logic established: ${configData.strategyName}`]);

        setLogs(prev => [...prev, "> Synthesizing unique abstract visual iconography via neural rendering..."]);
        const imgResp: GenerateContentResponse = await apiService.generateIcon(`Abstract technological data visualization, neural network background, cyberpunk digital art, glowing blue and violet lines, dark obsidian surfaces, 4k high definition, detailed isometric machinery silhouette for an income engine named ${finalName}. Visual focus: ${configData.visualPrompt}`)
        .catch(e => {
           setLogs(prev => [...prev, "> [WARN] Neural iconography failed. Protocol degraded to legacy visuals."]);
           addNotification('Icon Generation Warning', 'Neural iconography failed. Proceeding with legacy visuals.', 'warning');
           return { candidates: [] } as any;
        });

        const imgParts = imgResp.candidates?.[0]?.content?.parts;
        if (imgParts) {
            for (const part of imgParts) {
                if (part.inlineData) {
                    synthesizedUrl = `data:image/png;base64,${part.inlineData.data}`;
                    setLogs(prev => [...prev, "> [OK] Neural iconography rendered successfully."]);
                    break;
                }
            }
        }
        
        setLogs(prev => [...prev, "> Logic configuration established."]);
        setLogs(prev => [...prev, "> Preparing Architectural Manifest for review..."]);
        
        setTimeout(() => {
            setSynthesizedConfig(configData);
            setSynthesizedImage(synthesizedUrl);
            setIsSynthesizing(false);
            setShowConfirm(true);
        }, 1500);

    } catch (err: any) {
        setIsSynthesizing(false);
        const errorPayload = {
          title: err.title || "Grid Logic Exception",
          message: err.message || "An unhandled exception occurred during architectural node synthesis.",
          code: err.code || "ERR_SYNTH_UNHANDLED",
          failurePoint: err.failurePoint || "INTERNAL_GRID_PROTOCOL",
          remedy: err.remedy || "Attempt to re-initialize the deployment uplink. If persistent, purge node cache and verify Architect credentials.",
          technicalLogs: [err.originalError?.toString() || err.toString()]
        };
        setError(errorPayload);
        addNotification(errorPayload.title, errorPayload.message, 'critical');
        return;
    }
  };

  const handleFinalDeployment = () => {
    if (!synthesizedConfig) return;
    
    const basePerformance = 95 + Math.random() * 5;
    const modelName = AVAILABLE_MODELS.find(m => m.id === model)?.name || model;
    
    onDeploy({
        id: `engine_${Date.now()}`,
        name: customName.trim(),
        type: template.name,
        model: modelName,
        status: 'Active',
        revenue: 0, 
        uptime: 100, 
        performance: basePerformance, 
        transactions: 0,
        lastSync: new Date().toISOString(),
        config: synthesizedConfig,
        imageUrl: synthesizedImage,
        history: generateMockHistory(basePerformance),
        resources: isAdmin ? { cpu: cpuCount, ram: ramGB, region: targetRegion } : { cpu: 2, ram: 4, region: 'cluster-us-east' }
    });
  };

  if(error) return (
    <div className="max-w-4xl mx-auto py-20 px-4 animate-in zoom-in-95 duration-500">
      <Card blueprint className="p-12 border-red-500/30 bg-red-500/[0.01] space-y-10 shadow-3xl glass relative overflow-hidden">
         <div className="absolute top-0 right-0 p-12 opacity-[0.03] pointer-events-none">
            <ShieldAlert size={200} className="text-red-500" />
         </div>
         
         <header className="space-y-4 relative z-10">
            <div className="flex items-center gap-4">
               <div className="p-3 rounded-xl bg-red-500/10 text-red-500 animate-pulse">
                  <ShieldX size={32} />
               </div>
               <div className="space-y-1">
                  <h2 className="text-3xl font-black italic uppercase text-white tracking-tighter">{error.title}</h2>
                  <p className="text-[10px] font-black uppercase text-red-500/60 tracking-[0.3em] italic">System Diagnostic Report</p>
               </div>
            </div>
         </header>

         <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
            <section className="space-y-6">
               <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/5 space-y-3">
                  <h4 className="text-[10px] font-black uppercase text-white/30 italic flex items-center gap-2"><FileSearch size={14} /> Failure Details</h4>
                  <p className="text-sm text-white/80 italic leading-relaxed">{error.message}</p>
               </div>
               <div className="grid grid-cols-2 gap-4">
                  <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                     <p className="text-[9px] font-black uppercase text-white/30 italic">Error Code</p>
                     <p className="text-xs font-mono text-red-400 font-bold">{error.code}</p>
                  </div>
                  <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
                     <p className="text-[9px] font-black uppercase text-white/30 italic">Failure Point</p>
                     <p className="text-xs font-mono text-white/60 font-bold">{error.failurePoint}</p>
                  </div>
               </div>
            </section>

            <section className="space-y-6">
               <div className="p-6 rounded-2xl bg-blue-600/[0.03] border border-blue-500/20 space-y-3 shadow-glow-sm">
                  <h4 className="text-[10px] font-black uppercase text-blue-400/60 italic flex items-center gap-2"><Wrench size={14} /> Recommended Protocol</h4>
                  <p className="text-sm text-white/80 italic leading-relaxed">{error.remedy}</p>
               </div>
               <div className="p-6 rounded-2xl bg-black/40 border border-white/5 space-y-3 glass">
                  <h4 className="text-[10px] font-black uppercase text-white/20 italic flex items-center gap-2"><Terminal size={14} /> Trace History</h4>
                  <div className="max-h-24 overflow-y-auto scrollbar-hide space-y-1">
                     {error.technicalLogs?.map((log, i) => (
                        <p key={i} className="text-[9px] font-mono text-white/30 truncate">{log}</p>
                     ))}
                     <p className="text-[9px] font-mono text-blue-500/40">--- END OF STACK ---</p>
                  </div>
               </div>
            </section>
         </div>

         <footer className="flex flex-col sm:flex-row gap-4 pt-10 border-t border-white/5 relative z-10">
            <Button variant="secondary" onClick={() => { setError(null); setStep(3); }} icon={RotateCcw} className="flex-1 h-14">Recalibrate Identity DNA</Button>
            <Button variant="outline" onClick={onCancel} icon={X} className="h-14">Abort Deployment</Button>
         </footer>
      </Card>
    </div>
  );

  if(isSynthesizing) return (
    <div className="max-w-3xl mx-auto py-20 px-4 space-y-8">
      <Card blueprint className="p-10 text-center space-y-8 shadow-glow glass">
        <div className="relative">
          <Activity size={48} className="text-blue-500 mx-auto animate-spin" />
          <div className="absolute inset-0 border-2 border-blue-500/20 rounded-full animate-ping"></div>
        </div>
        <h3 className="text-2xl font-black italic uppercase text-white">Synthesizing Architecture & Visuals</h3>
        <div className="h-48 font-mono text-left text-xs overflow-y-auto scrollbar-hide space-y-2 p-6 bg-black/60 rounded-lg border border-white/5 glass">
          {logs.map((l, i) => <p key={i} className="text-green-400 animate-in fade-in slide-in-from-left-1 mb-1">{l}</p>)}
          <div className="w-2 h-4 bg-green-400 animate-pulse inline-block align-middle ml-1"></div>
        </div>
      </Card>
    </div>
  );

  return (
    <div className="space-y-12 animate-in fade-in max-w-5xl mx-auto py-10 px-4 relative">
      {showConfirm && (
        <DeploymentConfirmationModal 
          config={{ 
            name: customName, 
            type: template?.name || 'N/A', 
            model: AVAILABLE_MODELS.find(m => m.id === model)?.name || 'N/A', 
            brief,
            yieldProfile: synthesizedConfig?.projectedRevenue || template?.yield || 'Stable Yield',
            templateDesc: template?.description || 'No operational data provided.'
          }} 
          imageUrl={synthesizedImage}
          resources={isAdmin ? { cpu: cpuCount, ram: ramGB, region: targetRegion } : undefined}
          onConfirm={handleFinalDeployment} 
          onCancel={() => setShowConfirm(false)} 
        />
      )}

      <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-8 pb-8 border-b border-white/5">
        <div className="space-y-2">
          <h1 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter text-white">Node Deployment</h1>
          <p className="text-white/40 text-sm italic font-medium">Phase {step} of {isAdmin ? 5 : 4}: {['Topology', 'Neural Core', 'Identity & Strategy', 'Advanced Provisioning', 'Final Registry'][isAdmin || step < 4 ? step - 1 : step]}</p>
        </div>
        <div className="flex items-center gap-3">
          {[1,2,3,4,5].filter(s => isAdmin || s !== 4).map((s, i) => (
            <div key={s} className={`w-10 h-10 rounded-xl flex items-center justify-center border transition-all duration-500 ${step === s ? 'bg-blue-600 border-blue-500 text-white shadow-glow' : step > s ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400' : 'bg-white/5 border-white/10 text-white/20'}`}>
              {step > s ? <Check size={20} /> : (isAdmin ? s : i + 1)}
            </div>
          ))}
        </div>
      </div>

      <div className="min-h-[400px]">
        {step === 1 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in slide-in-from-right-4 duration-500">
            {ENGINE_TEMPLATES.map((t) => (
              <Card 
                key={t.id} 
                blueprint 
                image={templateIcons[t.id] || DEFAULT_ENGINE_IMAGE}
                className={`p-8 border-2 transition-all cursor-pointer min-h-[320px] flex flex-col justify-end ${template?.id === t.id ? 'border-blue-600 bg-blue-600/5 shadow-glow-sm' : 'border-white/5 hover:border-white/20'}`} 
                onClick={() => setTemplate(t)}
              >
                <div className="relative z-10">
                  <t.icon size={32} className={`mb-4 ${t.color}`} />
                  <h4 className="text-2xl font-black italic uppercase text-white mb-2">{t.name}</h4>
                  <p className="text-sm text-white/40 italic leading-relaxed mb-4">{t.description}</p>
                  <Badge variant="info">{t.yield}</Badge>
                </div>
              </Card>
            ))}
          </div>
        )}

        {step === 2 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in slide-in-from-right-4 duration-500">
            {AVAILABLE_MODELS.map(m => (
              <Card key={m.id} blueprint className={`p-8 border-2 transition-all cursor-pointer ${model === m.id ? 'border-blue-600 bg-blue-600/5 shadow-glow-sm' : 'border-white/5 hover:border-white/20'}`} onClick={() => setModel(m.id)}>
                <m.icon size={32} className="mb-4 text-blue-500" />
                <h4 className="text-2xl font-black italic uppercase text-white mb-2">{m.name}</h4>
                <p className="text-sm text-white/40 italic">{m.description}</p>
              </Card>
            ))}
          </div>
        )}

        {step === 3 && (
          <div className="animate-in slide-in-from-right-4 duration-500 space-y-6">
            <Card blueprint className="p-10 space-y-10 glass">
              <div className="space-y-4">
                <label className="text-[10px] font-black uppercase text-white/30 tracking-widest italic flex items-center gap-2">
                  <Tag size={14} className="text-blue-500" /> Node Alias (Display Name)
                </label>
                <div className="relative group">
                  <input 
                    type="text" 
                    value={customName}
                    onChange={e => setCustomName(e.target.value)}
                    placeholder="e.g. Maverick Yield Core"
                    className="w-full bg-black/40 border border-white/10 rounded-2xl p-6 pl-14 outline-none text-white italic focus:border-blue-600 transition-all text-xl glass placeholder:text-white/10"
                    maxLength={32}
                  />
                  <Tag className="absolute left-6 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-blue-500 transition-colors" size={20} />
                  <div className="absolute right-6 top-1/2 -translate-y-1/2 text-[10px] font-mono text-white/20">
                    {customName.length}/32
                  </div>
                </div>
              </div>

              <div className="space-y-4 pt-6 border-t border-white/5">
                <label className="text-[10px] font-black uppercase text-white/30 tracking-widest italic flex items-center gap-2">
                  <Terminal size={14} className="text-blue-500" /> Strategic Mission Briefing
                </label>
                <textarea 
                  value={brief} 
                  onChange={e => setBrief(e.target.value)} 
                  rows={4} 
                  placeholder={`Example: "Focus on automated affiliate signals in high-growth SaaS niches."`} 
                  className="w-full bg-black/40 border border-white/10 rounded-3xl p-8 outline-none text-white italic focus:border-blue-600 transition-all text-lg leading-relaxed glass"
                ></textarea>
              </div>
            </Card>
          </div>
        )}

        {step === 4 && isAdmin && (
           <div className="animate-in slide-in-from-right-4 duration-500 space-y-8">
              <Card blueprint className="p-10 space-y-12 glass border-blue-600/20">
                 <div className="flex items-center gap-4 border-b border-white/5 pb-6">
                    <div className="p-3 rounded-xl bg-blue-600/10 text-blue-500 shadow-glow-sm">
                       <Microscope size={24} />
                    </div>
                    <div className="space-y-1">
                       <h3 className="text-2xl font-black italic uppercase text-white tracking-tighter leading-none">Advanced Provisioning</h3>
                       <p className="text-[10px] font-black uppercase text-blue-500/60 tracking-[0.3em] italic">Infrastructure & Node Allocation (Admin Privileges Active)</p>
                    </div>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div className="space-y-10">
                       <div className="space-y-6">
                          <div className="flex justify-between items-end">
                             <div className="space-y-1">
                                <p className="text-[10px] font-black uppercase text-white/40 italic flex items-center gap-2"><Cpu size={14} /> Compute Capacity</p>
                                <p className="text-xl font-black text-white italic leading-none">{cpuCount} Logic Cores</p>
                             </div>
                             <span className="text-[9px] font-mono text-blue-500/40 uppercase">vCPU Allocation</span>
                          </div>
                          <input 
                             type="range" min="1" max="32" step="1" 
                             value={cpuCount} onChange={(e) => setCpuCount(parseInt(e.target.value))}
                             className="w-full h-1.5 bg-white/5 rounded-lg appearance-none cursor-pointer accent-blue-600"
                          />
                       </div>

                       <div className="space-y-6">
                          <div className="flex justify-between items-end">
                             <div className="space-y-1">
                                <p className="text-[10px] font-black uppercase text-white/40 italic flex items-center gap-2"><HardDrive size={14} /> Neural Memory</p>
                                <p className="text-xl font-black text-white italic leading-none">{ramGB} GB RAM</p>
                             </div>
                             <span className="text-[9px] font-mono text-blue-500/40 uppercase">L3 Cache Reservation</span>
                          </div>
                          <input 
                             type="range" min="2" max="128" step="2" 
                             value={ramGB} onChange={(e) => setRamGB(parseInt(e.target.value))}
                             className="w-full h-1.5 bg-white/5 rounded-lg appearance-none cursor-pointer accent-blue-600"
                          />
                       </div>
                    </div>

                    <div className="space-y-6">
                       <div className="space-y-2">
                          <p className="text-[10px] font-black uppercase text-white/40 italic flex items-center gap-2"><Globe size={14} /> Deployment Topology Cluster</p>
                          <div className="grid grid-cols-1 gap-3">
                             {REGIONAL_CLUSTERS.map(cluster => (
                                <button 
                                   key={cluster.id}
                                   onClick={() => setTargetRegion(cluster.id)}
                                   className={`p-4 rounded-xl border flex items-center justify-between transition-all group ${targetRegion === cluster.id ? 'bg-blue-600/10 border-blue-600 shadow-glow-sm' : 'bg-white/5 border-white/10 hover:border-white/20'}`}
                                >
                                   <div className="flex items-center gap-3">
                                      <div className={`w-2 h-2 rounded-full ${targetRegion === cluster.id ? 'bg-blue-500 animate-pulse' : 'bg-white/10 group-hover:bg-white/30'}`}></div>
                                      <span className={`text-[11px] font-black uppercase italic tracking-widest ${targetRegion === cluster.id ? 'text-white' : 'text-white/40'}`}>{cluster.name}</span>
                                   </div>
                                   <span className="text-[9px] font-mono text-blue-500/40">Latency: {cluster.latency}</span>
                                </button>
                             ))}
                          </div>
                       </div>
                    </div>
                 </div>
              </Card>
           </div>
        )}

        {step === (isAdmin ? 5 : 4) && (
          <div className="animate-in zoom-in-95 duration-500">
            <Card blueprint className="p-10 space-y-10 bg-white/[0.01] glass">
               <div className="grid grid-cols-1 sm:grid-cols-3 gap-10">
                  <div className="space-y-2">
                     <p className="text-[10px] font-black uppercase text-white/30 tracking-widest italic">Node Alias</p>
                     <span className="text-xl font-black italic uppercase text-blue-400">{customName || "[UNNAMED_CORE]"}</span>
                  </div>
                  <div className="space-y-2">
                     <p className="text-[10px] font-black uppercase text-white/30 tracking-widest italic">Node Topology</p>
                     <span className="text-xl font-black italic uppercase text-white">{template?.name}</span>
                  </div>
                  <div className="space-y-2">
                     <p className="text-[10px] font-black uppercase text-white/30 tracking-widest italic">Neural Model</p>
                     <span className="text-xl font-black italic uppercase text-white">{AVAILABLE_MODELS.find(m => m.id === model)?.name}</span>
                  </div>
               </div>

               {isAdmin && (
                  <div className="p-6 rounded-2xl bg-blue-600/[0.03] border border-blue-500/10 grid grid-cols-1 sm:grid-cols-3 gap-8">
                     <div className="space-y-1">
                        <p className="text-[9px] font-black uppercase text-blue-500/60 italic">Infra Provisioning</p>
                        <p className="text-xs font-bold text-white italic">{cpuCount} CPU / {ramGB} GB RAM</p>
                     </div>
                     <div className="space-y-1">
                        <p className="text-[9px] font-black uppercase text-blue-500/60 italic">Deployment Cluster</p>
                        <p className="text-xs font-bold text-white italic truncate">{REGIONAL_CLUSTERS.find(c => c.id === targetRegion)?.name}</p>
                     </div>
                     <div className="space-y-1 text-right">
                        <Badge variant="info">Admin Override Active</Badge>
                     </div>
                  </div>
               )}

               <div className="space-y-4 pt-10 border-t border-white/5">
                  <p className="text-[10px] font-black uppercase text-white/30 tracking-widest italic">Encoded Briefing DNA</p>
                  <p className="text-white/80 italic text-sm bg-black/20 p-6 rounded-2xl border border-white/5 whitespace-pre-wrap">{brief || "Default autonomous logic applied."}</p>
               </div>
            </Card>
          </div>
        )}
      </div>

      <div className="flex justify-between items-center pt-8 border-t border-white/5">
        <Button variant="outline" onClick={step === 1 ? onCancel : () => setStep(prev => prev - 1)} icon={step === 1 ? X : ArrowLeft}>
          {step === 1 ? 'Cancel' : 'Previous'}
        </Button>
        {step < (isAdmin ? 5 : 4) ? (
          <Button onClick={() => setStep(prev => prev + (step === 3 && !isAdmin ? 2 : 1))} icon={ArrowRight} disabled={(step === 1 && !template) || (step === 3 && !customName.trim())}>
            Continue
          </Button>
        ) : (
          <Button size="lg" onClick={handleSynthesize} icon={Zap} className="px-12 shadow-glow">
            Initiate Grid Deployment
          </Button>
        )}
      </div>
    </div>
  );
};

// Component to view full engine diagnostic details
const EngineDetailView = ({ engine, isAdmin, onBack, onDeleteRequest, onUpdateEngine }: { engine: Engine, isAdmin: boolean, onBack: () => void, onDeleteRequest: (e: Engine) => void, onUpdateEngine: (id: string, update: Partial<Engine>, notify?: boolean) => void }) => {
  const [isRunningDiagnostics, setIsRunningDiagnostics] = useState(false);

  const handleRunDiagnostics = async () => {
    setIsRunningDiagnostics(true);
    // Artificial delay to simulate neural processing
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    const newPerformance = Math.max(90, Math.min(100, engine.performance + (Math.random() * 4 - 1.5)));
    const newSync = new Date().toISOString();
    
    onUpdateEngine(engine.id, {
      performance: newPerformance,
      lastSync: newSync,
      history: [...(engine.history || []).slice(1), newPerformance]
    });
    
    setIsRunningDiagnostics(false);
  };

  const handleExportConfig = () => {
    // Explicitly include visualPrompt in the exported config as requested.
    const exportData = {
      ...engine.config,
      visualPrompt: engine.config.visualPrompt || "Standard Neural Pattern"
    };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportData, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `engine_config_${engine.name.replace(/\s+/g, '_').toLowerCase()}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleCopyDNA = () => {
    const dataStr = JSON.stringify(engine.config, null, 2);
    navigator.clipboard.writeText(dataStr);
  };

  const handleExportAnalytics = () => {
    const rows = [
      ["Metric", "Value"],
      ["Engine Name", engine.name],
      ["Engine ID", engine.id],
      ["Topology", engine.type],
      ["Model", engine.model],
      ["Current Status", engine.status],
      ["Total Liquidity Yield (USD)", engine.revenue.toFixed(4)],
      ["System Uptime (%)", engine.uptime],
      ["Current Efficiency (%)", engine.performance.toFixed(2)],
      ["Total Lifecycle Transactions", engine.transactions],
      ["CPU Cores", engine.resources?.cpu || 'N/A'],
      ["RAM GB", engine.resources?.ram || 'N/A'],
      ["Cluster Region", engine.resources?.region || 'N/A'],
      ["Visual Prompt", engine.config.visualPrompt || 'N/A'],
      ["", ""],
      ["Neural Telemetry (Last 24 Data Points)", "Efficiency Percentage (%)"]
    ];

    if (engine.history && engine.history.length > 0) {
      engine.history.forEach((val, i) => {
        rows.push([`Interval T-${engine.history!.length - i}`, val.toFixed(2)]);
      });
    }

    const csvContent = "data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `analytics_${engine.name.replace(/\s+/g, '_').toLowerCase()}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-24 px-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/5 pb-6 gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="p-2 hover:bg-white/5 rounded-full text-white/40 hover:text-white transition-colors">
              <ChevronLeft size={24} />
            </button>
            <h1 className="text-3xl md:text-5xl font-black italic uppercase tracking-tighter text-white">{engine.name}</h1>
          </div>
          <p className="text-[10px] font-black uppercase text-white/40 tracking-[0.4em] italic pl-12">Logic Node Diagnostic: {engine.id}</p>
        </div>
        <div className="flex flex-wrap items-center gap-4">
          {isAdmin && (
            <>
              <Button variant="secondary" size="sm" onClick={handleCopyDNA} icon={Copy}>Copy DNA</Button>
              <Button variant="secondary" size="sm" onClick={handleExportAnalytics} icon={Download}>Export Analytics (CSV)</Button>
              <Button variant="secondary" size="sm" onClick={handleExportConfig} icon={FileJson}>Export Config</Button>
            </>
          )}
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={handleRunDiagnostics} 
            loading={isRunningDiagnostics} 
            icon={Wrench}
          >
            Run Diagnostics
          </Button>
          <Badge variant={engine.status === 'Active' ? 'success' : 'warning'} live={engine.status === 'Active'}>{engine.status}</Badge>
          <Button variant="danger" size="sm" onClick={() => onDeleteRequest(engine)} icon={Trash2}>Decommission</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
             <Card blueprint className="p-8 space-y-4 glass">
                <MetabolismTicker value={engine.revenue} isMain label="Node Yield" />
                <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                   <p className="text-[9px] font-black uppercase text-white/20 italic">Cumulative Liquid Gains</p>
                   <TrendingUp size={14} className="text-emerald-500" />
                </div>
             </Card>
             <Card blueprint className="p-8 space-y-4 glass">
                <PerformanceGauge value={engine.performance} />
                <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                   <p className="text-[9px] font-black uppercase text-white/20 italic">Logic Optimization Level</p>
                   <Zap size={14} className="text-blue-500" />
                </div>
             </Card>
          </div>

          <PerformanceTimeline history={engine.history || []} />

          <Card blueprint className="p-10 space-y-10 glass">
            <div className="flex items-center gap-3 border-b border-white/5 pb-4">
              <Terminal size={20} className="text-blue-500" />
              <h3 className="text-xl font-black italic uppercase text-white">Synthesized Strategy DNA</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              {[
                { label: 'Attack Vector', val: engine.config.attackVector, icon: Crosshair },
                { label: 'Primary Lever', val: engine.config.lever, icon: Zap },
                { label: 'Economic Moat', val: engine.config.moat, icon: Shield },
                { label: 'Projected Flow', val: engine.config.projectedRevenue, icon: TrendingUp }
              ].map((item, i) => (
                <div key={i} className="space-y-2">
                  <p className="text-[10px] font-black uppercase text-white/30 italic tracking-widest flex items-center gap-2">
                     {item.icon && <item.icon size={12} />} {item.label}
                  </p>
                  <p className="text-sm text-white/80 italic leading-relaxed font-medium">{item.val || 'N/A'}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-8">
          <Card blueprint image={engine.imageUrl} className="aspect-square rounded-3xl border border-white/5 flex items-end p-8 glass overflow-hidden">
             <div className="relative z-10 space-y-1">
                <p className="text-[9px] font-black uppercase text-white/40 italic">Visual Core Identity</p>
                <p className="text-lg font-black italic text-white uppercase">{engine.type}</p>
             </div>
          </Card>
          
          <Card blueprint className="p-8 space-y-6">
            <h3 className="text-xs font-black italic uppercase text-white/40">Infrastructure Resources</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center text-[10px] font-bold italic uppercase text-white/60">
                <span className="flex items-center gap-2"><Cpu size={14}/> Compute</span>
                <span className="text-blue-500">{engine.resources?.cpu || 2} vCores</span>
              </div>
              <div className="flex justify-between items-center text-[10px] font-bold italic uppercase text-white/60">
                <span className="flex items-center gap-2"><HardDrive size={14}/> Memory</span>
                <span className="text-blue-500">{engine.resources?.ram || 4} GB RAM</span>
              </div>
              <div className="flex justify-between items-center text-[10px] font-bold italic uppercase text-white/60">
                <span className="flex items-center gap-2"><Globe size={14}/> Node Cluster</span>
                <span className="text-blue-500 truncate w-32 text-right">{REGIONAL_CLUSTERS.find(c => c.id === engine.resources?.region)?.name || 'US-East-1'}</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

// Component to manage treasury balance, notifications, and capital flow
const TreasuryHub = ({ 
  user, 
  transactions, 
  onOpenWithdraw, 
  notifications,
  onDismissNotification,
  onMarkAllAsRead
}: { 
  user: UserData, 
  transactions: Transaction[], 
  onOpenWithdraw: () => void,
  notifications: GridNotification[],
  onDismissNotification: (id: string) => void,
  onMarkAllAsRead: () => void
}) => {
  return (
    <div className="space-y-12 animate-in fade-in duration-500 pb-24 px-4">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 pb-4 border-b border-white/5">
        <div className="space-y-1">
          <h1 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter text-white leading-none">Treasury Hub</h1>
          <p className="text-white/40 text-sm italic uppercase tracking-widest font-black">Capital Flow & Liquidity Registry</p>
        </div>
        <Button onClick={onOpenWithdraw} variant="gold" size="lg" icon={Banknote} className="shadow-glow">Initiate Liquidity Exit</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card blueprint className="p-10 space-y-6 glass border-l-4 border-emerald-500">
               <div className="space-y-1">
                 <p className="text-[10px] font-black uppercase text-white/30 italic">Current Liquidity</p>
                 <div className="text-4xl font-black text-white italic tracking-tighter">$ {formatCurrency(user.balance)}</div>
               </div>
               <div className="flex items-center gap-2 text-emerald-400">
                  <TrendingUp size={16} />
                  <span className="text-[10px] font-black uppercase italic">Flow Nominal</span>
               </div>
            </Card>
            <Card blueprint className="p-10 space-y-6 glass border-l-4 border-blue-500">
               <div className="space-y-1">
                 <p className="text-[10px] font-black uppercase text-white/30 italic">Lifetime Yield</p>
                 <div className="text-4xl font-black text-white italic tracking-tighter">$ {formatCurrency(user.lifetimeYield)}</div>
               </div>
               <div className="flex items-center gap-2 text-blue-400">
                  <Layers size={16} />
                  <span className="text-[10px] font-black uppercase italic">Compound Growth Active</span>
               </div>
            </Card>
          </div>

          <Card blueprint className="p-8 space-y-8 glass">
             <div className="flex items-center justify-between border-b border-white/5 pb-4">
                <div className="flex items-center gap-3">
                   <History size={20} className="text-blue-500" />
                   <h3 className="text-xl font-black italic uppercase text-white">Transaction Logs</h3>
                </div>
                <span className="text-[10px] font-black uppercase text-white/20 italic">Last 50 Events</span>
             </div>
             <div className="space-y-4 max-h-[600px] overflow-y-auto pr-4 scrollbar-hide">
                {transactions.map(tx => (
                  <div key={tx.id} className="p-5 rounded-2xl bg-white/[0.02] border border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:bg-white/[0.04] transition-all group">
                     <div className="flex items-center gap-5">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${tx.type === 'credit' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>
                           {tx.type === 'credit' ? <ArrowUpRight size={24}/> : <ArrowDownRight size={24}/>}
                        </div>
                        <div className="space-y-1">
                           <p className="text-sm font-black italic uppercase text-white group-hover:text-blue-400 transition-colors">{tx.description}</p>
                           <p className="text-[10px] text-white/20 font-mono">{new Date(tx.date).toLocaleString()} • {tx.method}</p>
                        </div>
                     </div>
                     <div className="flex items-center gap-8 justify-between md:justify-end">
                        <div className="text-right">
                           <p className={`text-lg font-black italic ${tx.type === 'credit' ? 'text-emerald-400' : 'text-red-400'}`}>
                              {tx.type === 'credit' ? '+' : '-'}${formatCurrency(tx.amount)}
                           </p>
                           <p className="text-[9px] font-black uppercase text-white/20 italic">{tx.status}</p>
                        </div>
                        <div className="text-right opacity-0 group-hover:opacity-100 transition-opacity hidden md:block">
                           <p className="text-[8px] font-black uppercase text-white/20 italic">TX HASH</p>
                           <p className="text-[8px] font-mono text-blue-500/40 truncate w-24">{tx.txHash}</p>
                        </div>
                     </div>
                  </div>
                ))}
                {transactions.length === 0 && (
                  <div className="py-20 text-center opacity-20 space-y-4">
                     <ClipboardList size={48} className="mx-auto" />
                     <p className="text-xs font-black uppercase italic tracking-[0.3em]">No capital movements detected.</p>
                  </div>
                )}
             </div>
          </Card>
        </div>

        <div className="space-y-8">
           <Card blueprint className="p-8 space-y-6 h-full glass">
              <div className="flex items-center justify-between border-b border-white/5 pb-4">
                 <div className="flex items-center gap-3">
                    <Bell size={20} className="text-blue-500" />
                    <h3 className="text-lg font-black italic uppercase text-white">System Alerts</h3>
                 </div>
                 {notifications.length > 0 && (
                   <button onClick={onMarkAllAsRead} className="text-[9px] font-black uppercase text-blue-500/60 hover:text-blue-500 transition-colors italic">Mark All Read</button>
                 )}
              </div>
              <div className="space-y-4 overflow-y-auto max-h-[800px] pr-2 scrollbar-hide">
                 {notifications.map(notif => (
                   <div key={notif.id} className={`p-4 rounded-xl border transition-all relative group ${notif.read ? 'bg-black/20 border-white/5' : 'bg-blue-600/5 border-blue-500/20 shadow-glow-sm'}`}>
                      <div className="flex justify-between items-start mb-2">
                         <span className={`text-[9px] font-black uppercase italic tracking-widest ${notif.type === 'success' ? 'text-emerald-500' : 'text-blue-500'}`}>{notif.title}</span>
                         <button onClick={() => onDismissNotification(notif.id)} className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-500 transition-all"><X size={12} /></button>
                      </div>
                      <p className="text-[11px] text-white/60 italic leading-relaxed">{notif.message}</p>
                      <p className="text-[8px] font-mono text-white/20 mt-3">{new Date(notif.timestamp).toLocaleTimeString()}</p>
                      {!notif.read && <div className="absolute top-4 right-4 w-1.5 h-1.5 bg-blue-500 rounded-full"></div>}
                   </div>
                 ))}
                 {notifications.length === 0 && (
                   <div className="py-20 text-center opacity-10 space-y-4">
                      <ShieldCheck size={48} className="mx-auto" />
                      <p className="text-[10px] font-black uppercase italic tracking-[0.2em]">Matrix Silence.</p>
                   </div>
                 )}
              </div>
           </Card>
        </div>
      </div>
    </div>
  );
};

// Component to authorize and process capital withdrawals
const WithdrawalTerminal = ({ user, onClose, onWithdraw }: { user: UserData, onClose: () => void, onWithdraw: (amt: number, method: string) => void }) => {
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('Digital Wallet (USDT)');
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');

  const methods = [
    'Digital Wallet (USDT)',
    'Institutional Transfer (SWIFT)',
    'Crypto-Matrix Settlement (BTC)',
    'Grid Credit Allocation'
  ];

  const handleWithdraw = () => {
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) return setError('Invalid capital volume.');
    if (amt > user.balance) return setError('Insufficient grid liquidity.');
    
    setProcessing(true);
    setTimeout(() => {
      onWithdraw(amt, method);
      setProcessing(false);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-[2000] bg-black/95 backdrop-blur-3xl flex items-center justify-center p-6 animate-in fade-in duration-300">
      <div className="w-full max-w-md">
        <Card blueprint className="p-10 space-y-8 glass border-blue-500/20 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none -rotate-12">
             <Wallet size={200} className="text-blue-500" />
          </div>
          <header className="text-center space-y-4">
             <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20 mx-auto text-emerald-500">
                <Banknote size={32} />
             </div>
             <div className="space-y-1">
                <h3 className="text-2xl font-black italic uppercase text-white tracking-tighter leading-tight">Liquidity Exit</h3>
                <p className="text-blue-500/60 text-[10px] font-black uppercase tracking-[0.3em] italic">Treasury Authorization Required</p>
             </div>
          </header>

          <div className="space-y-6">
             <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-white/30 italic tracking-widest flex justify-between">
                   Amount (USD) 
                   <span className="text-white/60">Available: ${formatCurrency(user.balance)}</span>
                </label>
                <div className="relative group">
                   <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-emerald-500 transition-colors" size={18} />
                   <input 
                     type="number"
                     value={amount}
                     onChange={e => { setAmount(e.target.value); setError(''); }}
                     className="w-full h-14 bg-black/40 border border-white/10 rounded-xl pl-12 pr-4 outline-none text-white font-black italic text-xl focus:border-emerald-500/40 transition-all glass"
                     placeholder="0.00"
                   />
                </div>
             </div>

             <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-white/30 italic tracking-widest">Settlement Method</label>
                <div className="grid grid-cols-1 gap-2">
                   {methods.map(m => (
                     <button 
                       key={m} 
                       onClick={() => setMethod(m)}
                       className={`p-4 rounded-xl border flex items-center justify-between transition-all group ${method === m ? 'bg-blue-600/10 border-blue-600 shadow-glow-sm' : 'bg-white/5 border-white/10 hover:border-white/20'}`}
                     >
                        <span className={`text-[10px] font-black uppercase italic tracking-widest ${method === m ? 'text-white' : 'text-white/40'}`}>{m}</span>
                        <div className={`w-3 h-3 rounded-full border transition-all ${method === m ? 'bg-blue-500 border-blue-400 shadow-glow-sm' : 'border-white/20'}`}></div>
                     </button>
                   ))}
                </div>
             </div>

             {error && (
               <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-xs text-center italic flex items-center gap-2 justify-center">
                  <AlertTriangle size={14} /> {error}
               </div>
             )}
          </div>

          <div className="flex flex-col gap-3">
             <Button onClick={handleWithdraw} loading={processing} disabled={processing || !amount} size="lg" className="w-full h-14" variant="success" icon={CheckCheck}>Authorize Settlement</Button>
             <Button onClick={onClose} variant="outline" className="w-full" icon={X}>Abort Protocol</Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

const GridHealth = ({ anomalies, onResolve, onResolveAll }: { anomalies: Anomaly[], onResolve: (id: string, isRecalibration: boolean) => void, onResolveAll: () => void }) => {
  const criticalCount = anomalies.filter(a => a.severity === 'critical').length;
  const warningCount = anomalies.filter(a => a.severity === 'warning').length;

  return (
    <div className="space-y-12 animate-in fade-in duration-500 pb-24 px-4">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 pb-4 border-b border-white/5">
        <div className="space-y-1">
          <h1 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter text-white leading-none">Grid Health</h1>
          <p className="text-white/40 text-sm italic uppercase tracking-widest font-black">Anomaly Detection & Resolution Terminal</p>
        </div>
        {anomalies.length > 0 && (
          <Button onClick={onResolveAll} variant="secondary" size="lg" icon={ShieldCheck} className="shadow-glow">
            Resolve All ({anomalies.length})
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card blueprint className="p-10 space-y-6 glass border-l-4 border-red-500">
          <div className="space-y-1">
            <p className="text-[10px] font-black uppercase text-white/30 italic">Critical Anomalies</p>
            <div className="text-4xl font-black text-red-400 italic tracking-tighter">{criticalCount}</div>
          </div>
          <div className="flex items-center gap-2 text-red-400">
            <AlertTriangle size={16} />
            <span className="text-[10px] font-black uppercase italic">Immediate Action Required</span>
          </div>
        </Card>
        <Card blueprint className="p-10 space-y-6 glass border-l-4 border-yellow-500">
          <div className="space-y-1">
            <p className="text-[10px] font-black uppercase text-white/30 italic">Warning Signals</p>
            <div className="text-4xl font-black text-yellow-400 italic tracking-tighter">{warningCount}</div>
          </div>
          <div className="flex items-center gap-2 text-yellow-400">
            <Info size={16} />
            <span className="text-[10px] font-black uppercase italic">Monitoring Advised</span>
          </div>
        </Card>
      </div>

      {anomalies.length > 0 ? (
        <div className="space-y-8">
          {anomalies.map(anomaly => (
            <Card key={anomaly.id} blueprint className={`p-8 space-y-6 glass border ${anomaly.severity === 'critical' ? 'border-red-500/20' : 'border-yellow-500/20'}`}>
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-3">
                    <Badge variant={anomaly.severity === 'critical' ? 'danger' : 'warning'}>{anomaly.severity}</Badge>
                    <h3 className="text-xl font-black italic uppercase text-white">{anomaly.title}</h3>
                  </div>
                  <p className="text-[10px] font-mono text-white/40">
                    Node: <span className="text-blue-400">{anomaly.engineName}</span> // Detected: {new Date(anomaly.timestamp).toLocaleString()}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Button variant="secondary" size="sm" icon={Wrench} onClick={() => onResolve(anomaly.id, true)}>Recalibrate Node</Button>
                  <Button variant="outline" size="sm" icon={X} onClick={() => onResolve(anomaly.id, false)}>Dismiss Alert</Button>
                </div>
              </div>
              <p className="text-sm text-white/60 italic leading-relaxed border-t border-white/5 pt-6">{anomaly.description